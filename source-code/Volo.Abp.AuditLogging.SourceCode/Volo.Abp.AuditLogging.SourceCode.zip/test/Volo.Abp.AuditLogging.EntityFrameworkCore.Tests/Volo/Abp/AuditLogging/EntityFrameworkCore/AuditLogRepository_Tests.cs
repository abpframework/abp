﻿namespace Volo.Abp.AuditLogging.EntityFrameworkCore;

public class AuditLogRepository_Tests : AuditLogRepository_Tests<AbpAuditLoggingEntityFrameworkCoreTestModule>
{

}
