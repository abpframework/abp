export const enum eSettingManagementRouteNames {
  Settings = 'AbpSettingManagement::Settings',
}
