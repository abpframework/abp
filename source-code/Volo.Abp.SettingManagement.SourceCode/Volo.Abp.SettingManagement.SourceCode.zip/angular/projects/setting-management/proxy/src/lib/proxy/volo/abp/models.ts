
export interface NameValue<T = "string"> {
  name?: string;
  value: T;
}
