import { InjectionToken } from '@angular/core';

export const LAZY_STYLES = new InjectionToken<string[]>('LAZY_STYLES');
