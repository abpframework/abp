﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Shouldly;
using Volo.Abp.Authorization.Permissions;
using Volo.Abp.Data;
using Volo.Abp.Features;
using Volo.Abp.GlobalFeatures;
using Volo.Abp.Localization;
using Volo.Abp.MultiTenancy;
using Volo.Abp.PermissionManagement.Localization;
using Xunit;

namespace Volo.Abp.PermissionManagement;

public class PermissionDefinitionSerializer_Tests : PermissionTestBase
{
    private readonly IPermissionDefinitionSerializer _serializer;

    public PermissionDefinitionSerializer_Tests()
    {
        _serializer = GetRequiredService<IPermissionDefinitionSerializer>();
    }

    [Fact]
    public async Task Serialize_Permission_Group_Definition()
    {
        // Arrange

        var context = new PermissionDefinitionContext(null);
        var group1 = CreatePermissionGroup1(context);

        // Act

        var permissionGroupRecord = await _serializer.SerializeAsync(group1);

        //Assert

        permissionGroupRecord.Name.ShouldBe("Group1");
        permissionGroupRecord.DisplayName.ShouldBe("F:Group one");
        permissionGroupRecord.GetProperty("CustomProperty1").ShouldBe("CustomValue1");
    }

    [Fact]
    public async Task Serialize_Complex_Permission_Definition()
    {
        // Arrange

        var context = new PermissionDefinitionContext(null);
        var group1 = CreatePermissionGroup1(context);
        var permission1 = group1.AddPermission(
                "Permission1",
                new LocalizableString(typeof(AbpPermissionManagementResource), "Permission1"),
                MultiTenancySides.Tenant
            )
            .WithProviders("ProviderA", "ProviderB")
            .WithProperty("CustomProperty2", "CustomValue2")
            .RequireAuthenticated() //For for testing, not so meaningful
            .RequireGlobalFeatures("GlobalFeature1", "GlobalFeature2")
            .RequireFeatures(requiresAll: true, batchCheck: false, "Feature1", "Feature2")
            .RequirePermissions(requiresAll: false, batchCheck: false,"Permission2", "Permission3");

        // Act

        var permissionRecord = await _serializer.SerializeAsync(
            permission1,
            group1
        );

        //Assert

        permissionRecord.Name.ShouldBe("Permission1");
        permissionRecord.GroupName.ShouldBe("Group1");
        permissionRecord.DisplayName.ShouldBe("L:AbpPermissionManagement,Permission1");
        permissionRecord.GetProperty("CustomProperty2").ShouldBe("CustomValue2");
        permissionRecord.Providers.ShouldBe("ProviderA,ProviderB");
        permissionRecord.MultiTenancySide.ShouldBe(MultiTenancySides.Tenant);
        permissionRecord.StateCheckers.ShouldBe("[{\"T\":\"A\"},{\"T\":\"G\",\"A\":true,\"N\":[\"GlobalFeature1\",\"GlobalFeature2\"]},{\"T\":\"F\",\"A\":true,\"N\":[\"Feature1\",\"Feature2\"]},{\"T\":\"P\",\"A\":false,\"N\":[\"Permission2\",\"Permission3\"]}]");
    }


    [Fact]
    public async Task Serialize_Permission_With_Default_Batch_RequireFeatures()
    {
        var context = new PermissionDefinitionContext(null);
        var group = context.AddGroup("AbpAuditLogging");
        var permission = group.AddPermission(
                "AbpAuditLogging.Settings",
                new LocalizableString(typeof(AbpPermissionManagementResource), "Permission1"))
            .RequireFeatures("AbpAuditLogging.SettingManagement");

        var record = await _serializer.SerializeAsync(permission, group);

        record.StateCheckers.ShouldBe(
            "[{\"T\":\"F\",\"A\":true,\"N\":[\"AbpAuditLogging.SettingManagement\"]}]");
    }

    [Fact]
    public async Task Serialize_Permission_With_Default_Batch_RequireFeatures_Picks_Per_State_Model()
    {
        var context = new PermissionDefinitionContext(null);
        var group = context.AddGroup("Group1");

        var permA = group.AddPermission("PermA", new LocalizableString(typeof(AbpPermissionManagementResource), "Permission1"))
            .RequireFeatures("FeatureForA");
        var permB = group.AddPermission("PermB", new LocalizableString(typeof(AbpPermissionManagementResource), "Permission1"))
            .RequireFeatures("FeatureForB1", "FeatureForB2");

        var recordA = await _serializer.SerializeAsync(permA, group);
        var recordB = await _serializer.SerializeAsync(permB, group);

        recordA.StateCheckers.ShouldBe("[{\"T\":\"F\",\"A\":true,\"N\":[\"FeatureForA\"]}]");
        recordB.StateCheckers.ShouldBe("[{\"T\":\"F\",\"A\":true,\"N\":[\"FeatureForB1\",\"FeatureForB2\"]}]");
    }

    [Fact]
    public async Task Serialize_Permission_With_Default_Batch_RequirePermissions()
    {
        var context = new PermissionDefinitionContext(null);
        var group = context.AddGroup("Group1");
        var permission = group.AddPermission(
                "Permission1",
                new LocalizableString(typeof(AbpPermissionManagementResource), "Permission1"))
            .RequirePermissions("OtherPermission1", "OtherPermission2");

        var record = await _serializer.SerializeAsync(permission, group);

        record.StateCheckers.ShouldBe(
            "[{\"T\":\"P\",\"A\":true,\"N\":[\"OtherPermission1\",\"OtherPermission2\"]}]");
    }

    [Fact]
    public async Task Serialize_Permission_With_Default_Batch_RequirePermissions_Picks_Per_State_Model()
    {
        var context = new PermissionDefinitionContext(null);
        var group = context.AddGroup("Group1");

        var permA = group.AddPermission("PermA", new LocalizableString(typeof(AbpPermissionManagementResource), "Permission1"))
            .RequirePermissions("OtherForA");
        var permB = group.AddPermission("PermB", new LocalizableString(typeof(AbpPermissionManagementResource), "Permission1"))
            .RequirePermissions(requiresAll: false, "OtherForB1", "OtherForB2");

        var recordA = await _serializer.SerializeAsync(permA, group);
        var recordB = await _serializer.SerializeAsync(permB, group);

        recordA.StateCheckers.ShouldBe("[{\"T\":\"P\",\"A\":true,\"N\":[\"OtherForA\"]}]");
        recordB.StateCheckers.ShouldBe("[{\"T\":\"P\",\"A\":false,\"N\":[\"OtherForB1\",\"OtherForB2\"]}]");
    }

    [Fact]
    public async Task Serialize_Complex_Resource_Permission_Definition()
    {
        // Arrange

        var context = new PermissionDefinitionContext(null);
        var resourcePermission1 = context.AddResourcePermission(
                "ResourcePermission1",
                TestEntityResource.ResourceName,
                "Permission1",
                new LocalizableString(typeof(AbpPermissionManagementResource), "ResourcePermission1"),
                MultiTenancySides.Tenant
            )
            .WithProviders("ProviderA", "ProviderB")
            .WithProperty("CustomProperty2", "CustomValue2")
            .RequireAuthenticated() //For for testing, not so meaningful
            .RequireGlobalFeatures("GlobalFeature1", "GlobalFeature2")
            .RequireFeatures(requiresAll: true, batchCheck: false, "Feature1", "Feature2")
            .RequirePermissions(requiresAll: false, batchCheck: false,"Permission2", "Permission3");

        // Act

        var permissionRecord = await _serializer.SerializeAsync(
            resourcePermission1,
            null
        );

        //Assert

        permissionRecord.Name.ShouldBe("ResourcePermission1");
        permissionRecord.GroupName.ShouldBe(null);
        permissionRecord.ResourceName.ShouldBe(TestEntityResource.ResourceName);
        permissionRecord.ManagementPermissionName.ShouldBe("Permission1");
        permissionRecord.DisplayName.ShouldBe("L:AbpPermissionManagement,ResourcePermission1");
        permissionRecord.GetProperty("CustomProperty2").ShouldBe("CustomValue2");
        permissionRecord.Providers.ShouldBe("ProviderA,ProviderB");
        permissionRecord.MultiTenancySide.ShouldBe(MultiTenancySides.Tenant);
        permissionRecord.StateCheckers.ShouldBe("[{\"T\":\"A\"},{\"T\":\"G\",\"A\":true,\"N\":[\"GlobalFeature1\",\"GlobalFeature2\"]},{\"T\":\"F\",\"A\":true,\"N\":[\"Feature1\",\"Feature2\"]},{\"T\":\"P\",\"A\":false,\"N\":[\"Permission2\",\"Permission3\"]}]");
    }


    private static PermissionGroupDefinition CreatePermissionGroup1(
        IPermissionDefinitionContext context)
    {
        var group = context.AddGroup(
            "Group1",
            displayName: new FixedLocalizableString("Group one")
        );

        group["CustomProperty1"] = "CustomValue1";

        return group;
    }
}
