using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Volo.Abp.DependencyInjection;
using Volo.Abp.Localization;

namespace Volo.Abp.PermissionManagement;

public class TestResourcePermissionProviderKeyLookupService : IResourcePermissionProviderKeyLookupService, ITransientDependency
{
    public string Name => "Test";

    public ILocalizableString DisplayName => new LocalizableString("Test", "TestResource");

    public Task<bool> IsAvailableAsync()
    {
        return Task.FromResult(true);
    }

    public Task<List<ResourcePermissionProviderKeyInfo>> SearchAsync(string filter = null, int page = 1, CancellationToken cancellationToken = default)
    {
        throw new System.NotImplementedException();
    }

    public Task<List<ResourcePermissionProviderKeyInfo>> SearchAsync(string[] keys, CancellationToken cancellationToken = default)
    {
        return Task.FromResult(keys.Select(key => new ResourcePermissionProviderKeyInfo(key, key)).ToList());
    }
}
