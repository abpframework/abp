﻿namespace Volo.Abp.PermissionManagement.EntityFrameworkCore;

public class EFCorePermissionDefinitionRecordRepository_Tests : PermissionDefinitionRecordRepository_Tests
{

}
