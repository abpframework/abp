﻿namespace Volo.Abp.PermissionManagement;

public class ProviderInfoDto
{
    public string ProviderName { get; set; }

    public string ProviderKey { get; set; }
}
