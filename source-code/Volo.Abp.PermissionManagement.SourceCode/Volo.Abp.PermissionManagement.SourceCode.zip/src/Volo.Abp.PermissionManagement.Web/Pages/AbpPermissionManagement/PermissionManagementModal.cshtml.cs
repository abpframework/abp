using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Volo.Abp.AspNetCore.Mvc.ApplicationConfigurations;
using Volo.Abp.AspNetCore.Mvc.UI.RazorPages;
using Volo.Abp.Authorization.Permissions;
using Volo.Abp.EventBus.Local;
using Volo.Abp.Localization;
using Volo.Abp.PermissionManagement.Web.Utils;

namespace Volo.Abp.PermissionManagement.Web.Pages.AbpPermissionManagement;

public class PermissionManagementModal : AbpPageModel
{
    [Required]
    [HiddenInput]
    [BindProperty(SupportsGet = true)]
    public string ProviderName { get; set; }

    [Required]
    [HiddenInput]
    [BindProperty(SupportsGet = true)]
    public string ProviderKey { get; set; }

    [BindProperty(SupportsGet = true)]
    public string ProviderKeyDisplayName { get; set; }

    [BindProperty]
    public List<PermissionGroupViewModel> Groups { get; set; }

    /* A replaced view that still posts the whole Groups tree does not set this, so it keeps working. */
    [BindProperty]
    public bool OnlyChangedPermissions { get; set; }

    [BindProperty]
    public string GrantedPermissionNames { get; set; }

    [BindProperty]
    public string RevokedPermissionNames { get; set; }

    public string EntityDisplayName { get; set; }

    public bool SelectAllInThisTab { get; set; }

    public bool SelectAllInAllTabs { get; set; }

    protected IPermissionAppService PermissionAppService { get; }

    protected ILocalEventBus LocalEventBus { get; }
    public AbpLocalizationOptions LocalizationOptions { get; }

    public PermissionManagementModal(
        IPermissionAppService permissionAppService,
        ILocalEventBus localEventBus,
        IOptions<AbpLocalizationOptions> localizationOptions)
    {
        ObjectMapperContext = typeof(AbpPermissionManagementWebModule);

        PermissionAppService = permissionAppService;
        LocalEventBus = localEventBus;
        LocalizationOptions = localizationOptions.Value;
    }

    public virtual async Task<IActionResult> OnGetAsync()
    {
        ValidateModel();

        var result = await PermissionAppService.GetAsync(ProviderName, ProviderKey);

        EntityDisplayName = !string.IsNullOrWhiteSpace(ProviderKeyDisplayName)
            ? ProviderKeyDisplayName
            : result.EntityDisplayName;

        Groups = ObjectMapper
            .Map<List<PermissionGroupDto>, List<PermissionGroupViewModel>>(result.Groups)
            .OrderBy(g => g.DisplayName)
            .ToList();

        foreach (var group in Groups)
        {
            new FlatTreeDepthFinder<PermissionGrantInfoViewModel>().SetDepths(group.Permissions);
        }

        foreach (var group in Groups)
        {
            group.IsAllPermissionsGranted = group.Permissions.All(p => p.IsGranted);
        }

        SelectAllInAllTabs = Groups.All(g => g.IsAllPermissionsGranted);

        return Page();
    }

    public virtual async Task<IActionResult> OnPostAsync()
    {
        ValidateModel();

        var updatePermissionDtos = OnlyChangedPermissions
            ? GetChangedPermissions()
            : Groups
                .SelectMany(g => g.Permissions)
                .Select(p => new UpdatePermissionDto
                {
                    Name = p.Name,
                    IsGranted = p.IsGranted
                })
                .ToArray();

        if (updatePermissionDtos.IsNullOrEmpty())
        {
            return NoContent();
        }

        await PermissionAppService.UpdateAsync(
            ProviderName,
            ProviderKey,
            new UpdatePermissionsDto
            {
                Permissions = updatePermissionDtos
            }
        );

        Guid? userId = null;
        if (ProviderName == UserPermissionValueProvider.ProviderName && Guid.TryParse(ProviderKey, out var parsedUserId))
        {
            userId = parsedUserId;
        }

        await LocalEventBus.PublishAsync(new CurrentApplicationConfigurationCacheResetEventData(userId));

        return NoContent();
    }

    protected virtual UpdatePermissionDto[] GetChangedPermissions()
    {
        var permissions = new Dictionary<string, bool>();

        foreach (var name in SplitPermissionNames(GrantedPermissionNames))
        {
            permissions[name] = true;
        }

        foreach (var name in SplitPermissionNames(RevokedPermissionNames))
        {
            permissions[name] = false;
        }

        return permissions
            .Select(permission => new UpdatePermissionDto { Name = permission.Key, IsGranted = permission.Value })
            .ToArray();
    }

    protected virtual string[] SplitPermissionNames(string names)
    {
        return names.IsNullOrWhiteSpace()
            ? Array.Empty<string>()
            : names.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
    }

    public class PermissionGroupViewModel
    {
        public string Name { get; set; }

        public bool IsAllPermissionsGranted { get; set; }

        public string DisplayName { get; set; }

        public List<PermissionGrantInfoViewModel> Permissions { get; set; }

        public string GetNormalizedGroupName()
        {
            return Name.Replace(".", "_");
        }

        public bool IsDisabled(string currentProviderName)
        {
            return Permissions.All(p => p.IsDisabled(currentProviderName));
        }
    }

    public class PermissionGrantInfoViewModel : IFlatTreeItem
    {
        [Required]
        [HiddenInput]
        public string Name { get; set; }

        public string DisplayName { get; set; }

        public int Depth { get; set; }

        public string ParentName { get; set; }

        public bool IsGranted { get; set; }

        public List<string> AllowedProviders { get; set; }

        public List<ProviderInfoViewModel> GrantedProviders { get; set; }

        public bool IsEditable { get; set; }

        public bool IsDisabled(string currentProviderName)
        {
            return !IsEditable || (IsGranted && GrantedProviders.All(p => p.ProviderName != currentProviderName));
        }

        public string GetShownName(string currentProviderName)
        {
            if (!IsDisabled(currentProviderName))
            {
                return DisplayName;
            }

            var grantedByOtherProviders = GrantedProviders
                .Where(p => p.ProviderName != currentProviderName)
                .Select(p => p.ProviderName)
                .ToList();

            if (!grantedByOtherProviders.Any())
            {
                return DisplayName;
            }

            return string.Format(
                "{0} ({1})",
                DisplayName,
                grantedByOtherProviders.JoinAsString(", ")
            );
        }
    }

    public class ProviderInfoViewModel
    {
        public string ProviderName { get; set; }

        public string ProviderKey { get; set; }
    }
}
