﻿namespace Volo.Abp.IdentityServer.ApiResources;

public class ApiResourceScopeConsts
{
    public static int ScopeMaxLength { get; set; } = 200;
}
