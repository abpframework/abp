﻿namespace Volo.Abp.IdentityServer.ApiResources;

public class ApiResourcePropertyConsts
{
    public static int KeyMaxLength { get; set; } = 250;

    public static int ValueMaxLength { get; set; } = 2000;
}
