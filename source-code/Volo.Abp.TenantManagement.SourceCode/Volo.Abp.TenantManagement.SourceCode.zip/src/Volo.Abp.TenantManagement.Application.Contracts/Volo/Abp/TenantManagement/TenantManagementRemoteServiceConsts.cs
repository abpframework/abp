﻿namespace Volo.Abp.TenantManagement;

public class TenantManagementRemoteServiceConsts
{
    public const string RemoteServiceName = "AbpTenantManagement";

    public const string ModuleName = "multi-tenancy";
}
