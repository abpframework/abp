﻿namespace Volo.Abp.TenantManagement.Web.Navigation;

public class TenantManagementMenuNames
{
    public const string GroupName = "TenantManagement";

    public const string Tenants = GroupName + ".Tenants";
}
