﻿namespace Volo.Abp.TenantManagement.Blazor.Navigation;

public class TenantManagementMenuNames
{
    public const string GroupName = "TenantManagement";

    public const string Tenants = GroupName + ".Tenants";
}
