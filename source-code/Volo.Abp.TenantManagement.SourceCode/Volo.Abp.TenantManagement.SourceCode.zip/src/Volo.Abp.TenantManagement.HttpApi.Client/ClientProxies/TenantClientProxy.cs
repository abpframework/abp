// This file is part of TenantClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Abp.TenantManagement.ClientProxies;

public partial class TenantClientProxy
{
}
