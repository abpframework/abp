export const enum eTenantManagementComponents {
  Tenants = 'TenantManagement.TenantsComponent',
}
