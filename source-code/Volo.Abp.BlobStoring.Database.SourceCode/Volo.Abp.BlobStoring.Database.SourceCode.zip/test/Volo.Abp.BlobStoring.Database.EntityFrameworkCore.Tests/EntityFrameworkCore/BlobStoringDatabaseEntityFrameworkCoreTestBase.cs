﻿namespace Volo.Abp.BlobStoring.Database.EntityFrameworkCore;

public abstract class BlobStoringDatabaseEntityFrameworkCoreTestBase : BlobStoringDatabaseTestBase<BlobStoringDatabaseEntityFrameworkCoreTestModule>
{

}
