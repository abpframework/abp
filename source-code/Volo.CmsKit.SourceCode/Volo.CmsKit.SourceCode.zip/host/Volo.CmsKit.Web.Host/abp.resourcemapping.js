module.exports = {
    aliases: {
        
    },
    mappings: {
        
    }
};
