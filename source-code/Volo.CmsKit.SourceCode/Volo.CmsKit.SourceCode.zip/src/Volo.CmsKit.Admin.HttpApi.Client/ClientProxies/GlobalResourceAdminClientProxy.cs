// This file is part of GlobalResourceAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Admin.GlobalResources.ClientProxies;

public partial class GlobalResourceAdminClientProxy
{
}
