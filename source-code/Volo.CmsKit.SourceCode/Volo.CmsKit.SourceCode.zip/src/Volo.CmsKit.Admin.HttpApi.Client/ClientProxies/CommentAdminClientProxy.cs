// This file is part of CommentAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Admin.Comments.ClientProxies;

public partial class CommentAdminClientProxy
{
}
