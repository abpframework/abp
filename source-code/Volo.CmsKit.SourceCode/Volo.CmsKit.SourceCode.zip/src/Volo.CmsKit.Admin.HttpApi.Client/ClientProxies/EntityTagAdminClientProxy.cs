// This file is part of EntityTagAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Admin.Tags.ClientProxies;

public partial class EntityTagAdminClientProxy
{
}
