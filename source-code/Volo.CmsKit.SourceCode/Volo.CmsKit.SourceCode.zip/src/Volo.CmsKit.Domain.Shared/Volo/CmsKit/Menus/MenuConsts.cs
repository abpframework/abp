﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Volo.CmsKit.Menus;

public static class MenuConsts
{
    public static int MaxNameLength { get; set; } = 128;
}
