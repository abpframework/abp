﻿namespace Volo.CmsKit.Blogs;

public enum BlogPostStatus
{
    Draft,
    Published,
    WaitingForReview
}