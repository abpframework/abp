﻿using Volo.CmsKit.Web.Icons;

namespace Volo.CmsKit.Web.Reactions;

public class ReactionIconDictionary : LocalizableIconDictionaryBase
{
}
