// This file is part of BlogFeatureClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Blogs.ClientProxies;

public partial class BlogFeatureClientProxy
{
}
