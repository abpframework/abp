// This file is part of MediaDescriptorClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.MediaDescriptors.ClientProxies;

public partial class MediaDescriptorClientProxy
{
}
