// This file is part of TagPublicClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Public.Tags.ClientProxies;

public partial class TagPublicClientProxy
{
}
