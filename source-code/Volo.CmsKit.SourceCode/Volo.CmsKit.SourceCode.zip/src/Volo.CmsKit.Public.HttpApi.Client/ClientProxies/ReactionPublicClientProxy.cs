// This file is part of ReactionPublicClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Public.Reactions.ClientProxies;

public partial class ReactionPublicClientProxy
{
}
