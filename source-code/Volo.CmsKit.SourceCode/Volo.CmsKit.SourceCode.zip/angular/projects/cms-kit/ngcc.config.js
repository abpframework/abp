module.exports = {
  entryPoints: {
    ".": {},
    "./config": {},
    "./dist": { ignore: true },
  },
};
