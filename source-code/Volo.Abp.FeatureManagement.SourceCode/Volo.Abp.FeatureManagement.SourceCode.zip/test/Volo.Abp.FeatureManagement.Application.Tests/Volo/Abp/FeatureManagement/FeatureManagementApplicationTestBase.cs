﻿namespace Volo.Abp.FeatureManagement;

public class FeatureManagementApplicationTestBase : FeatureManagementTestBase<FeatureManagementApplicationTestModule>
{

}
