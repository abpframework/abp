export const enum eFeatureManagementTabNames {
  FeatureManagement = 'AbpFeatureManagement::Permission:FeatureManagement',
}
