export const enum eIdentityComponents {
  Roles = 'Identity.RolesComponent',
  Users = 'Identity.UsersComponent',
}
