import {
  InitDirective,
  ListService,
  LocalizationPipe,
  PagedResultDto,
  ReplaceableTemplateDirective,
} from '@abp/ng.core';
import {
  GetIdentityUsersInput,
  IdentityRoleDto,
  IdentityUserDto,
  IdentityUserService,
} from '@abp/ng.identity/proxy';
import {
  ePermissionManagementComponents,
  PermissionManagementComponent,
} from '@abp/ng.permission-management';
import {
  ButtonComponent,
  Confirmation,
  ConfirmationService,
  eFormComponets,
  FormCheckboxComponent,
  ModalCloseDirective,
  ModalComponent,
  ToasterService,
} from '@abp/ng.theme.shared';
import {
  ExtensibleFormComponent,
  ExtensibleTableComponent,
  EXTENSIONS_IDENTIFIER,
  FormPropData,
  generateFormFromProps,
} from '@abp/ng.components/extensible';
import {
  Component,
  inject,
  Injector,
  signal,
  TemplateRef,
  TrackByFunction,
  viewChild,
  ChangeDetectionStrategy,
} from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import {
  AbstractControl,
  FormsModule,
  ReactiveFormsModule,
  UntypedFormArray,
  UntypedFormBuilder,
  UntypedFormGroup,
} from '@angular/forms';
import { finalize, switchMap, tap } from 'rxjs/operators';
import { eIdentityComponents } from '../../enums/components';
import { PageComponent } from '@abp/ng.components/page';
import { NgbDropdownModule, NgbNavModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxValidateCoreModule } from '@ngx-validate/core';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'abp-users',
  templateUrl: './users.component.html',
  providers: [
    ListService,
    {
      provide: EXTENSIONS_IDENTIFIER,
      useValue: eIdentityComponents.Users,
    },
  ],
  imports: [
    ReactiveFormsModule,
    FormsModule,
    PermissionManagementComponent,
    PageComponent,
    NgbDropdownModule,
    NgbNavModule,
    NgxValidateCoreModule,
    LocalizationPipe,
    ExtensibleTableComponent,
    ModalComponent,
    ExtensibleFormComponent,
    FormCheckboxComponent,
    ButtonComponent,
    ReplaceableTemplateDirective,
    ModalCloseDirective,
    InitDirective,
  ],
})
export class UsersComponent {
  protected readonly list = inject(ListService<GetIdentityUsersInput>);
  protected readonly confirmationService = inject(ConfirmationService);
  protected readonly service = inject(IdentityUserService);
  protected readonly toasterService = inject(ToasterService);
  private readonly fb = inject(UntypedFormBuilder);
  private readonly injector = inject(Injector);

  readonly data = toSignal(
    this.list.hookToQuery(query => this.service.getList(query)),
    {
      initialValue: { items: [], totalCount: 0 } as PagedResultDto<IdentityUserDto>,
    },
  );

  readonly modalContent = viewChild.required<TemplateRef<any>>('modalContent');

  form!: UntypedFormGroup;

  selected?: IdentityUserDto;

  selectedTab = 'user-info';

  selectedUserRoles?: IdentityRoleDto[];

  readonly roles = signal<IdentityRoleDto[]>([]);

  readonly visiblePermissions = signal(false);

  providerKey?: string;

  readonly isModalVisible = signal(false);

  readonly modalBusy = signal(false);

  permissionManagementKey = ePermissionManagementComponents.PermissionManagement;

  entityDisplayName: string;

  inputKey = eFormComponets.FormCheckboxComponent;

  trackByFn: TrackByFunction<AbstractControl> = (index, item) => Object.keys(item)[0] || index;

  onVisiblePermissionChange = (event: boolean) => {
    this.visiblePermissions.set(event);
  };

  get roleGroups(): UntypedFormGroup[] {
    return ((this.form.get('roleNames') as UntypedFormArray)?.controls as UntypedFormGroup[]) || [];
  }

  buildForm() {
    const data = new FormPropData(this.injector, this.selected);
    this.form = generateFormFromProps(data);

    this.service.getAssignableRoles().subscribe(({ items }) => {
      this.roles.set(items);
      if (items?.length) {
        this.form.addControl(
          'roleNames',
          this.fb.array(
            items.map(role =>
              this.fb.group({
                [role.name as string]: [
                  this.selected?.id
                    ? !!this.selectedUserRoles?.find(userRole => userRole.id === role.id)
                    : role.isDefault,
                ],
              }),
            ),
          ),
        );
      }
    });
  }

  openModal() {
    this.selectedTab = 'user-info';
    this.buildForm();
    this.isModalVisible.set(true);
  }

  add() {
    this.selected = {} as IdentityUserDto;
    this.selectedUserRoles = [] as IdentityRoleDto[];
    this.openModal();
  }

  edit(id: string) {
    this.service
      .get(id)
      .pipe(
        tap(user => (this.selected = user)),
        switchMap(() => this.service.getRoles(id)),
      )
      .subscribe(userRole => {
        this.selectedUserRoles = userRole.items || [];
        this.openModal();
      });
  }

  save() {
    if (!this.form.valid || this.modalBusy()) return;
    this.modalBusy.set(true);

    const { roleNames = [] } = this.form.value;
    const mappedRoleNames =
      roleNames
        .filter((role: { [key: string]: any }) => !!role[Object.keys(role)[0]])
        .map((role: { [key: string]: any }) => Object.keys(role)[0]) || [];

    const { id } = this.selected || {};

    (id
      ? this.service.update(id, {
          ...this.selected,
          ...this.form.value,
          roleNames: mappedRoleNames,
        })
      : this.service.create({ ...this.form.value, roleNames: mappedRoleNames })
    )
      .pipe(finalize(() => this.modalBusy.set(false)))
      .subscribe(() => {
        this.isModalVisible.set(false);
        this.toasterService.success('AbpUi::SavedSuccessfully');
        this.list.get();
      });
  }

  delete(id: string, userName: string) {
    this.confirmationService
      .warn('AbpIdentity::UserDeletionConfirmationMessage', 'AbpIdentity::AreYouSure', {
        messageLocalizationParams: [userName],
      })
      .subscribe((status: Confirmation.Status) => {
        if (status === Confirmation.Status.confirm) {
          this.service.delete(id).subscribe(() => {
            this.toasterService.success('AbpUi::DeletedSuccessfully');
            this.list.get();
          });
        }
      });
  }

  sort(data: { sorts?: { prop: string; dir: string }[] } | { prop: string; dir: string }[]) {
    const sorts = Array.isArray(data) ? data : data?.sorts;
    if (!sorts?.length) {
      return;
    }

    const { prop, dir } = sorts[0];
    this.list.sortKey = prop;
    this.list.sortOrder = dir;
  }

  openPermissionsModal(providerKey: string, entityDisplayName?: string) {
    this.providerKey = providerKey;
    this.entityDisplayName = entityDisplayName;
    setTimeout(() => {
      this.visiblePermissions.set(true);
    }, 0);
  }
}
