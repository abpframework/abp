using Xunit;

namespace Volo.Abp.Identity.MongoDB;

[Collection(MongoTestCollection.Name)]
public class IdentityUserDelegationepository_Tests: IdentityUserDelegationepository_Tests<AbpIdentityMongoDbTestModule>
{
    
}