﻿using System;
using Volo.Abp.DependencyInjection;

namespace Volo.Abp.Identity;

public class IdentityTestData : ISingletonDependency
{
    public Guid UserAdminId { get; } = Guid.NewGuid();
    public Guid RoleModeratorId { get; } = Guid.NewGuid();
    public Guid RoleSupporterId { get; } = Guid.NewGuid();
    public Guid RoleManagerId { get; } = Guid.NewGuid();
    public Guid RoleSaleId { get; } = Guid.NewGuid();
    public Guid UserJohnId { get; } = Guid.NewGuid();
    public Guid UserDavidId { get; } = Guid.NewGuid();
    public Guid UserNeoId { get; } = Guid.NewGuid();
    public Guid UserBobId { get; } = Guid.NewGuid();
    public Guid AgeClaimId { get; } = Guid.NewGuid();
    public Guid EducationClaimId { get; } = Guid.NewGuid();
    public byte[] PasskeyCredentialId1 { get; } = (byte[])[1, 2, 3, 4, 5, 6, 7, 8];
    public byte[] PasskeyCredentialId2 { get; } = (byte[])[8, 7, 6, 5, 4, 3, 2, 1];
    public byte[] PasskeyCredentialId3 { get; } = (byte[])[1, 2, 3, 4, 8, 7, 6, 5,];
}
