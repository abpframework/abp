﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volo.Abp.Identity.EntityFrameworkCore;

public class Identity_Repository_Resolve_Tests : Identity_Repository_Resolve_Tests<AbpIdentityEntityFrameworkCoreTestModule>
{
}
