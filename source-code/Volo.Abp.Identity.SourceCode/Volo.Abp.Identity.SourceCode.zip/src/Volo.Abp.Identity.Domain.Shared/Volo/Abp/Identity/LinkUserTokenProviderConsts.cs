﻿namespace Volo.Abp.Identity;

public static class LinkUserTokenProviderConsts
{
    public static string LinkUserTokenProviderName { get; set; } = "AbpLinkUser";

    public static string LinkUserTokenPurpose { get; set; } = "AbpLinkUser";

    public static string LinkUserLoginTokenPurpose { get; set; } = "AbpLinkUserLogin";
}
