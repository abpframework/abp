﻿namespace Volo.Abp.Identity;

public static class IdentityRemoteServiceConsts
{
    public const string RemoteServiceName = "AbpIdentity";

    public const string ModuleName = "identity";
}
