// This file is part of IdentityUserClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Abp.Identity.ClientProxies;

public partial class IdentityUserClientProxy
{
}
