// This file is part of IdentityRoleClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Abp.Identity.ClientProxies;

public partial class IdentityRoleClientProxy
{
}
