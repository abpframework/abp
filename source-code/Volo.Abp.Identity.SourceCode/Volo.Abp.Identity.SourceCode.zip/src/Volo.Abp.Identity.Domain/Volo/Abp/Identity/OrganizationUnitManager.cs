﻿using Microsoft.Extensions.Localization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Volo.Abp.Caching;
using Volo.Abp.Domain.Services;
using Volo.Abp.Identity.Localization;
using Volo.Abp.Security.Claims;
using Volo.Abp.Threading;
using Volo.Abp.Uow;

namespace Volo.Abp.Identity;

/// <summary>
/// Performs domain logic for Organization Units.
/// </summary>
public class OrganizationUnitManager : DomainService
{
    protected IOrganizationUnitRepository OrganizationUnitRepository { get; }
    protected IStringLocalizer<IdentityResource> Localizer { get; }
    protected IIdentityRoleRepository IdentityRoleRepository { get; }
    protected IDistributedCache<AbpDynamicClaimCacheItem> DynamicClaimCache { get; }
    protected ICancellationTokenProvider CancellationTokenProvider { get; }

    public OrganizationUnitManager(
        IOrganizationUnitRepository organizationUnitRepository,
        IStringLocalizer<IdentityResource> localizer,
        IIdentityRoleRepository identityRoleRepository,
        IDistributedCache<AbpDynamicClaimCacheItem> dynamicClaimCache,
        ICancellationTokenProvider cancellationTokenProvider)
    {
        OrganizationUnitRepository = organizationUnitRepository;
        Localizer = localizer;
        IdentityRoleRepository = identityRoleRepository;
        DynamicClaimCache = dynamicClaimCache;
        CancellationTokenProvider = cancellationTokenProvider;
    }

    [UnitOfWork]
    public virtual async Task CreateAsync(OrganizationUnit organizationUnit)
    {
        await ValidateParentTenantAsync(organizationUnit.ParentId, organizationUnit.TenantId);

        organizationUnit.Code = await GetNextChildCodeAsync(organizationUnit.ParentId);
        await ValidateOrganizationUnitAsync(organizationUnit);
        await OrganizationUnitRepository.InsertAsync(organizationUnit);
    }

    /// <summary>
    /// Creates the given organization units by querying the siblings of a parent once instead of once
    /// per organization unit. They all have to belong to the current tenant and their parents must
    /// already exist. <see cref="GetNextChildCodeAsync"/> is used for the first organization unit of a
    /// parent, the codes of the rest follow it. Custom validation should be added by overriding
    /// <see cref="ValidateOrganizationUnitAsync(OrganizationUnit, List{OrganizationUnit})"/>.
    /// </summary>
    [UnitOfWork]
    public virtual async Task CreateManyAsync(List<OrganizationUnit> organizationUnits)
    {
        Check.NotNull(organizationUnits, nameof(organizationUnits));

        if (organizationUnits.Any(x => x.TenantId != CurrentTenant.Id))
        {
            throw new AbpException("Organization units of another tenant can not be created, change the current tenant instead!");
        }

        var groups = organizationUnits.GroupBy(x => x.ParentId).ToList();

        foreach (var group in groups)
        {
            await ValidateParentTenantAsync(group.Key, CurrentTenant.Id);

            var siblings = await FindChildrenAsync(group.Key);
            string lastCode = null;

            foreach (var organizationUnit in group)
            {
                organizationUnit.Code = lastCode = lastCode == null
                    ? await GetNextChildCodeAsync(group.Key)
                    : OrganizationUnit.CalculateNextCode(lastCode);

                await ValidateOrganizationUnitAsync(organizationUnit, siblings);

                siblings.Add(organizationUnit);
            }
        }

        //Nothing is inserted before every group is validated.
        foreach (var group in groups)
        {
            await OrganizationUnitRepository.InsertManyAsync(group.ToList());
        }
    }

    public virtual async Task UpdateAsync(OrganizationUnit organizationUnit)
    {
        await ValidateOrganizationUnitAsync(organizationUnit);
        await OrganizationUnitRepository.UpdateAsync(organizationUnit);
        await RemoveDynamicClaimCacheAsync(organizationUnit);
    }

    public virtual async Task<string> GetNextChildCodeAsync(Guid? parentId)
    {
        var lastChild = await GetLastChildOrNullAsync(parentId);
        if (lastChild != null)
        {
            return OrganizationUnit.CalculateNextCode(lastChild.Code);
        }

        var parentCode = parentId != null
            ? await GetCodeOrDefaultAsync(parentId.Value)
            : null;

        return OrganizationUnit.AppendCode(
            parentCode,
            OrganizationUnit.CreateCode(1)
        );
    }

    public virtual async Task<OrganizationUnit> GetLastChildOrNullAsync(Guid? parentId)
    {
        var children = await OrganizationUnitRepository.GetChildrenAsync(parentId);
        return children.OrderBy(c => c.Code).LastOrDefault();
    }

    [UnitOfWork]
    public virtual async Task DeleteAsync(Guid id)
    {
        var children = await FindChildrenAsync(id, true);

        foreach (var child in children)
        {
            await RemoveDynamicClaimCacheAsync(child);
            await OrganizationUnitRepository.RemoveAllMembersAsync(child);
            await OrganizationUnitRepository.RemoveAllRolesAsync(child);
            await OrganizationUnitRepository.DeleteAsync(child);
        }

        var organizationUnit = await OrganizationUnitRepository.GetAsync(id);

        await RemoveDynamicClaimCacheAsync(organizationUnit);
        await OrganizationUnitRepository.RemoveAllMembersAsync(organizationUnit);
        await OrganizationUnitRepository.RemoveAllRolesAsync(organizationUnit);
        await OrganizationUnitRepository.DeleteAsync(id);
    }

    [UnitOfWork]
    public virtual async Task MoveAsync(Guid id, Guid? parentId)
    {
        var organizationUnit = await OrganizationUnitRepository.GetAsync(id);
        if (organizationUnit.ParentId == parentId)
        {
            return;
        }

        await ValidateParentTenantAsync(parentId, organizationUnit.TenantId);

        //Should find children before Code change
        var children = await FindChildrenAsync(id, true);

        //Store old code of OU
        var oldCode = organizationUnit.Code;

        //Move OU
        organizationUnit.Code = await GetNextChildCodeAsync(parentId);
        organizationUnit.ParentId = parentId;

        await ValidateOrganizationUnitAsync(organizationUnit);

        //Update Children Codes
        foreach (var child in children)
        {
            child.Code = OrganizationUnit.AppendCode(organizationUnit.Code, OrganizationUnit.GetRelativeCode(child.Code, oldCode));
            await OrganizationUnitRepository.UpdateAsync(child);
        }

        await OrganizationUnitRepository.UpdateAsync(organizationUnit);
    }

    public virtual async Task<string> GetCodeOrDefaultAsync(Guid id)
    {
        var ou = await OrganizationUnitRepository.FindAsync(id);
        return ou?.Code;
    }

    protected virtual async Task ValidateOrganizationUnitAsync(OrganizationUnit organizationUnit)
    {
        await ValidateOrganizationUnitAsync(organizationUnit, await FindChildrenAsync(organizationUnit.ParentId));
    }

    /// <summary>
    /// Validates the organization unit against the given siblings, so they are not queried again.
    /// </summary>
    protected virtual Task ValidateOrganizationUnitAsync(OrganizationUnit organizationUnit, List<OrganizationUnit> siblings)
    {
        if (siblings.Any(ou => ou.Id != organizationUnit.Id && ou.DisplayName == organizationUnit.DisplayName))
        {
            throw new BusinessException(IdentityErrorCodes.DuplicateOrganizationUnitDisplayName)
                .WithData("0", organizationUnit.DisplayName);
        }

        return Task.CompletedTask;
    }

    protected virtual async Task ValidateParentTenantAsync(Guid? parentId, Guid? tenantId)
    {
        if (!parentId.HasValue)
        {
            return;
        }

        var parent = await OrganizationUnitRepository.FindAsync(parentId.Value);
        if (parent == null || parent.TenantId != tenantId)
        {
            throw new BusinessException(IdentityErrorCodes.OrganizationUnitParentTenantMismatch)
                .WithData("ParentId", parentId);
        }
    }

    public virtual async Task<List<OrganizationUnit>> FindChildrenAsync(Guid? parentId, bool recursive = false)
    {
        if (!recursive)
        {
            return await OrganizationUnitRepository.GetChildrenAsync(parentId, includeDetails: true);
        }

        if (!parentId.HasValue)
        {
            return await OrganizationUnitRepository.GetListAsync(includeDetails: true);
        }

        var code = await GetCodeOrDefaultAsync(parentId.Value);

        return await OrganizationUnitRepository.GetAllChildrenWithParentCodeAsync(code, parentId, includeDetails: true);
    }

    public virtual Task<bool> IsInOrganizationUnitAsync(IdentityUser user, OrganizationUnit ou)
    {
        return Task.FromResult(user.IsInOrganizationUnit(ou.Id));
    }

    public virtual async Task AddRoleToOrganizationUnitAsync(Guid roleId, Guid ouId)
    {
        await AddRoleToOrganizationUnitAsync(
            await IdentityRoleRepository.GetAsync(roleId),
            await OrganizationUnitRepository.GetAsync(ouId, true)
            );
    }

    public virtual async Task AddRoleToOrganizationUnitAsync(IdentityRole role, OrganizationUnit ou)
    {
        var currentRoles = ou.Roles;

        if (currentRoles.Any(r => r.OrganizationUnitId == ou.Id && r.RoleId == role.Id))
        {
            return;
        }
        ou.AddRole(role.Id);
        await OrganizationUnitRepository.UpdateAsync(ou);
        await RemoveDynamicClaimCacheAsync(ou);
    }

    public virtual async Task RemoveRoleFromOrganizationUnitAsync(Guid roleId, Guid ouId)
    {
        await RemoveRoleFromOrganizationUnitAsync(
            await IdentityRoleRepository.GetAsync(roleId),
            await OrganizationUnitRepository.GetAsync(ouId, true)
            );
    }

    public virtual async Task RemoveRoleFromOrganizationUnitAsync(IdentityRole role, OrganizationUnit organizationUnit)
    {
        organizationUnit.RemoveRole(role.Id);
        await OrganizationUnitRepository.UpdateAsync(organizationUnit);
        await RemoveDynamicClaimCacheAsync(organizationUnit);
    }

    public virtual async Task RemoveDynamicClaimCacheAsync(OrganizationUnit organizationUnit)
    {
        Logger.LogDebug($"Remove dynamic claims cache for users of organization: {organizationUnit.Id}");
        var userIds = await OrganizationUnitRepository.GetMemberIdsAsync(organizationUnit.Id);
        await DynamicClaimCache.RemoveManyAsync(userIds.Select(userId => AbpDynamicClaimCacheItem.CalculateCacheKey(userId, organizationUnit.TenantId)));
    }
}
