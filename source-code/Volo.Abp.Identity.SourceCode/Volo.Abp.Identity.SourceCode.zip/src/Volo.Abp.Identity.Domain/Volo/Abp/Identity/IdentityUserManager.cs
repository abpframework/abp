﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using JetBrains.Annotations;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Volo.Abp.Caching;
using Volo.Abp.Data;
using Volo.Abp.Domain.Entities;
using Volo.Abp.Domain.Repositories;
using Volo.Abp.Domain.Services;
using Volo.Abp.EventBus.Distributed;
using Volo.Abp.Identity.Settings;
using Volo.Abp.MultiTenancy;
using Volo.Abp.Security.Claims;
using Volo.Abp.Settings;
using Volo.Abp.Threading;
using Volo.Abp.Uow;

namespace Volo.Abp.Identity;

public class IdentityUserManager : UserManager<IdentityUser>, IDomainService
{
    protected IIdentityRoleRepository RoleRepository { get; }
    protected IIdentityUserRepository UserRepository { get; }
    protected IOrganizationUnitRepository OrganizationUnitRepository { get; }
    protected ISettingProvider SettingProvider { get; }
    protected ICancellationTokenProvider CancellationTokenProvider { get; }
    protected IDistributedEventBus DistributedEventBus { get; }
    protected IIdentityLinkUserRepository IdentityLinkUserRepository { get; }
    protected IDistributedCache<AbpDynamicClaimCacheItem> DynamicClaimCache { get; }
    protected override CancellationToken CancellationToken => CancellationTokenProvider.Token;
    protected IOptions<AbpMultiTenancyOptions> MultiTenancyOptions { get; }
    protected ICurrentTenant CurrentTenant { get; }
    protected IDataFilter DataFilter { get; }
    protected IUnitOfWorkManager UnitOfWorkManager { get; }

    public IdentityUserManager(
        IdentityUserStore store,
        IIdentityRoleRepository roleRepository,
        IIdentityUserRepository userRepository,
        IOptions<IdentityOptions> optionsAccessor,
        IPasswordHasher<IdentityUser> passwordHasher,
        IEnumerable<IUserValidator<IdentityUser>> userValidators,
        IEnumerable<IPasswordValidator<IdentityUser>> passwordValidators,
        ILookupNormalizer keyNormalizer,
        IdentityErrorDescriber errors,
        IServiceProvider services,
        ILogger<IdentityUserManager> logger,
        ICancellationTokenProvider cancellationTokenProvider,
        IOrganizationUnitRepository organizationUnitRepository,
        ISettingProvider settingProvider,
        IDistributedEventBus distributedEventBus,
        IIdentityLinkUserRepository identityLinkUserRepository,
        IDistributedCache<AbpDynamicClaimCacheItem> dynamicClaimCache,
        IOptions<AbpMultiTenancyOptions> multiTenancyOptions,
        ICurrentTenant currentTenant,
        IDataFilter dataFilter,
        IUnitOfWorkManager unitOfWorkManager)
        : base(
            store,
            optionsAccessor,
            passwordHasher,
            userValidators,
            passwordValidators,
            keyNormalizer,
            errors,
            services,
            logger)
    {
        OrganizationUnitRepository = organizationUnitRepository;
        SettingProvider = settingProvider;
        DistributedEventBus = distributedEventBus;
        RoleRepository = roleRepository;
        UserRepository = userRepository;
        IdentityLinkUserRepository = identityLinkUserRepository;
        DynamicClaimCache = dynamicClaimCache;
        MultiTenancyOptions = multiTenancyOptions;
        CurrentTenant = currentTenant;
        DataFilter = dataFilter;
        UnitOfWorkManager = unitOfWorkManager;
        CancellationTokenProvider = cancellationTokenProvider;
    }

    public virtual async Task<IdentityResult> CreateAsync(IdentityUser user, string password, bool validatePassword)
    {
        var result = await UpdatePasswordHash(user, password, validatePassword);
        if (!result.Succeeded)
        {
            return result;
        }

        return await CreateAsync(user);
    }

    public async override Task<IdentityResult> DeleteAsync(IdentityUser user)
    {
        user.Claims.Clear();
        user.Roles.Clear();
        user.Tokens.Clear();
        user.Logins.Clear();
        user.OrganizationUnits.Clear();
        await IdentityLinkUserRepository.DeleteAsync(new IdentityLinkUserInfo(user.Id, user.TenantId), CancellationToken);
        await UpdateAsync(user);

        return await base.DeleteAsync(user);
    }

    protected async override Task<IdentityResult> UpdateUserAsync(IdentityUser user)
    {
        var result = await base.UpdateUserAsync(user);

        if (result.Succeeded)
        {
            await DynamicClaimCache.RemoveAsync(AbpDynamicClaimCacheItem.CalculateCacheKey(user.Id, user.TenantId), token: CancellationToken);
        }

        return result;
    }

    /// <summary>
    /// This is to call the protection method ValidateUserAsync
    /// Should return <see cref="IdentityResult.Success"/> if validation is successful. This is
    /// called before saving the user via Create or Update.
    /// </summary>
    /// <param name="user">The user</param>
    /// <returns>A <see cref="IdentityResult"/> representing whether validation was successful.</returns>
    public virtual async Task<IdentityResult> CallValidateUserAsync(IdentityUser user)
    {
        return await ValidateUserAsync(user);
    }

    /// <summary>
    /// This is to call the protection method ValidatePasswordAsync
    /// Should return <see cref="IdentityResult.Success"/> if validation is successful. This is
    /// called before updating the password hash.
    /// </summary>
    /// <param name="user">The user.</param>
    /// <param name="password">The password.</param>
    /// <returns>A <see cref="IdentityResult"/> representing whether validation was successful.</returns>
    public virtual async Task<IdentityResult> CallValidatePasswordAsync(IdentityUser user, string password)
    {
        return await ValidatePasswordAsync(user, password);
    }

    /// <summary>
    /// This is to call the protection method UpdatePasswordHash
    /// Updates a user's password hash.
    /// </summary>
    /// <param name="user">The user.</param>
    /// <param name="newPassword">The new password.</param>
    /// <param name="validatePassword">Whether to validate the password.</param>
    /// <returns>Whether the password has was successfully updated.</returns>
    public virtual async Task<IdentityResult> CallUpdatePasswordHash(IdentityUser user, string newPassword, bool validatePassword)
    {
        return await UpdatePasswordHash(user, newPassword, validatePassword);
    }

    public virtual async Task<IdentityUser> GetByIdAsync(Guid id)
    {
        var user = await Store.FindByIdAsync(id.ToString(), CancellationToken);
        if (user == null)
        {
            throw new EntityNotFoundException(typeof(IdentityUser), id);
        }

        return user;
    }

    public virtual async Task UpdateLastSignInTimeAsync(Guid id, DateTimeOffset? lastSignInTime = null)
    {
        var time = lastSignInTime ?? DateTimeOffset.UtcNow;

        var currentUow = UnitOfWorkManager.Current;
        if (currentUow != null)
        {
            // The current unit of work may hold uncommitted changes of the same user (e.g. a new
            // registration or a lockout counter reset), so update the time after it completes.
            var tenantId = CurrentTenant.Id;
            currentUow.OnCompleted(async () =>
            {
                using (CurrentTenant.Change(tenantId))
                {
                    await TryUpdateLastSignInTimeAsync(id, time);
                }
            });

            return;
        }

        await TryUpdateLastSignInTimeAsync(id, time);
    }

    protected virtual async Task TryUpdateLastSignInTimeAsync(Guid id, DateTimeOffset lastSignInTime)
    {
        try
        {
            // Update the last sign-in time in a separate unit of work with a freshly
            // loaded user, so a concurrency conflict can't fail the current operation.
            using (var uow = UnitOfWorkManager.Begin(requiresNew: true))
            {
                var user = await Store.FindByIdAsync(id.ToString(), CancellationToken);
                if (user == null || user.LastSignInTime >= lastSignInTime)
                {
                    return;
                }

                user.SetLastSignInTime(lastSignInTime);

                var result = await UpdateAsync(user);
                if (result.Succeeded)
                {
                    await uow.CompleteAsync();
                }
            }
        }
        catch (Exception e)
        {
            // This is a best-effort update. The user may be updated concurrently
            // by another login or any other operation. Ignore the failure.
            Logger.LogException(e);
        }
    }

    public virtual async Task<IdentityResult> SetRolesAsync([NotNull] IdentityUser user,
        [NotNull] IEnumerable<string> roleNames)
    {
        Check.NotNull(user, nameof(user));
        Check.NotNull(roleNames, nameof(roleNames));

        var currentRoleNames = await GetRolesAsync(user);

        var result = await RemoveFromRolesAsync(user, currentRoleNames.Except(roleNames).Distinct());
        if (!result.Succeeded)
        {
            return result;
        }

        result = await AddToRolesAsync(user, roleNames.Except(currentRoleNames).Distinct());
        if (!result.Succeeded)
        {
            return result;
        }

        return IdentityResult.Success;
    }

    public virtual async Task<bool> IsInOrganizationUnitAsync(Guid userId, Guid ouId)
    {
        var user = await UserRepository.GetAsync(userId, cancellationToken: CancellationToken);
        return user.IsInOrganizationUnit(ouId);
    }

    public virtual async Task<bool> IsInOrganizationUnitAsync(IdentityUser user, OrganizationUnit ou)
    {
        await UserRepository.EnsureCollectionLoadedAsync(user, u => u.OrganizationUnits,
            CancellationTokenProvider.Token);
        return user.IsInOrganizationUnit(ou.Id);
    }

    public virtual async Task AddToOrganizationUnitAsync(Guid userId, Guid ouId)
    {
        await AddToOrganizationUnitAsync(
            await UserRepository.GetAsync(userId, cancellationToken: CancellationToken),
            await OrganizationUnitRepository.GetAsync(ouId, cancellationToken: CancellationToken)
        );
    }

    public virtual async Task AddToOrganizationUnitAsync(IdentityUser user, OrganizationUnit ou)
    {
        await UserRepository.EnsureCollectionLoadedAsync(user, u => u.OrganizationUnits,
            CancellationTokenProvider.Token);

        if (user.OrganizationUnits.Any(cou => cou.OrganizationUnitId == ou.Id))
        {
            return;
        }

        await CheckMaxUserOrganizationUnitMembershipCountAsync(user.OrganizationUnits.Count + 1);

        user.AddOrganizationUnit(ou.Id);
        await UserRepository.UpdateAsync(user, cancellationToken: CancellationToken);

        await DynamicClaimCache.RemoveAsync(AbpDynamicClaimCacheItem.CalculateCacheKey(user.Id, user.TenantId), token: CancellationToken);
    }

    public virtual async Task RemoveFromOrganizationUnitAsync(Guid userId, Guid ouId)
    {
        var user = await UserRepository.GetAsync(userId, cancellationToken: CancellationToken);
        user.RemoveOrganizationUnit(ouId);
        await UserRepository.UpdateAsync(user, cancellationToken: CancellationToken);

        await DynamicClaimCache.RemoveAsync(AbpDynamicClaimCacheItem.CalculateCacheKey(user.Id, user.TenantId), token: CancellationToken);
    }

    public virtual async Task RemoveFromOrganizationUnitAsync(IdentityUser user, OrganizationUnit ou)
    {
        await UserRepository.EnsureCollectionLoadedAsync(user, u => u.OrganizationUnits,
            CancellationTokenProvider.Token);

        user.RemoveOrganizationUnit(ou.Id);
        await UserRepository.UpdateAsync(user, cancellationToken: CancellationToken);
    }

    public virtual async Task SetOrganizationUnitsAsync(Guid userId, params Guid[] organizationUnitIds)
    {
        await SetOrganizationUnitsAsync(
            await UserRepository.GetAsync(userId, cancellationToken: CancellationToken),
            organizationUnitIds
        );
    }

    public virtual async Task SetOrganizationUnitsAsync(IdentityUser user, params Guid[] organizationUnitIds)
    {
        Check.NotNull(user, nameof(user));
        Check.NotNull(organizationUnitIds, nameof(organizationUnitIds));

        await CheckMaxUserOrganizationUnitMembershipCountAsync(organizationUnitIds.Length);

        await UserRepository.EnsureCollectionLoadedAsync(user, u => u.OrganizationUnits,
            CancellationTokenProvider.Token);

        //Remove from removed OUs
        foreach (var ouId in user.OrganizationUnits.Select(uou => uou.OrganizationUnitId).ToArray())
        {
            if (!organizationUnitIds.Contains(ouId))
            {
                user.RemoveOrganizationUnit(ouId);
            }
        }

        //Add to added OUs
        foreach (var organizationUnitId in organizationUnitIds)
        {
            if (!user.IsInOrganizationUnit(organizationUnitId))
            {
                user.AddOrganizationUnit(organizationUnitId);
            }
        }

        await UserRepository.UpdateAsync(user, cancellationToken: CancellationToken);
    }

    private async Task CheckMaxUserOrganizationUnitMembershipCountAsync(int requestedCount)
    {
        var maxCount =
            await SettingProvider.GetAsync<int>(IdentitySettingNames.OrganizationUnit.MaxUserMembershipCount);
        if (requestedCount > maxCount)
        {
            throw new BusinessException(IdentityErrorCodes.MaxAllowedOuMembership)
                .WithData("MaxUserMembershipCount", maxCount);
        }
    }

    [UnitOfWork]
    public virtual async Task<List<OrganizationUnit>> GetOrganizationUnitsAsync(IdentityUser user,
        bool includeDetails = false)
    {
        await UserRepository.EnsureCollectionLoadedAsync(user, u => u.OrganizationUnits,
            CancellationTokenProvider.Token);

        return await OrganizationUnitRepository.GetListAsync(
            user.OrganizationUnits.Select(t => t.OrganizationUnitId),
            includeDetails,
            cancellationToken: CancellationToken
        );
    }

    [UnitOfWork]
    public virtual async Task<List<IdentityUser>> GetUsersInOrganizationUnitAsync(
        OrganizationUnit organizationUnit,
        bool includeChildren = false)
    {
        if (includeChildren)
        {
            return await UserRepository
                .GetUsersInOrganizationUnitWithChildrenAsync(organizationUnit.Code, CancellationToken);
        }
        else
        {
            return await UserRepository
                .GetUsersInOrganizationUnitAsync(organizationUnit.Id, CancellationToken);
        }
    }

    public virtual async Task<IdentityResult> AddDefaultRolesAsync([NotNull] IdentityUser user)
    {
        await UserRepository.EnsureCollectionLoadedAsync(user, u => u.Roles, CancellationToken);

        foreach (var role in await RoleRepository.GetDefaultOnesAsync(cancellationToken: CancellationToken))
        {
            if (!user.IsInRole(role.Id))
            {
                user.AddRole(role.Id);
            }
        }

        return await UpdateUserAsync(user);
    }

    public virtual async Task<bool> ShouldPeriodicallyChangePasswordAsync(IdentityUser user)
    {
        Check.NotNull(user, nameof(user));

        if (user.PasswordHash.IsNullOrWhiteSpace())
        {
            return false;
        }

        var forceUsersToPeriodicallyChangePassword = await SettingProvider.GetAsync<bool>(IdentitySettingNames.Password.ForceUsersToPeriodicallyChangePassword);
        if (!forceUsersToPeriodicallyChangePassword)
        {
            return false;
        }

        var lastPasswordChangeTime = user.LastPasswordChangeTime ?? DateTime.SpecifyKind(user.CreationTime, DateTimeKind.Utc);
        var passwordChangePeriodDays = await SettingProvider.GetAsync<int>(IdentitySettingNames.Password.PasswordChangePeriodDays);

        return passwordChangePeriodDays > 0 && lastPasswordChangeTime.AddDays(passwordChangePeriodDays) < DateTime.UtcNow;
    }

    public virtual async Task ResetRecoveryCodesAsync(IdentityUser user)
    {
        if (!(Store is IdentityUserStore identityUserStore))
        {
            throw new AbpException($"Store is not an instance of {typeof(IdentityUserStore).AssemblyQualifiedName}");
        }

        await identityUserStore.SetTokenAsync(user, await identityUserStore.GetInternalLoginProviderAsync(), await identityUserStore.GetRecoveryCodeTokenNameAsync(), string.Empty, CancellationToken);
    }

    public async override Task<IdentityResult> SetEmailAsync(IdentityUser user, string email)
    {
        var oldMail = user.Email;

        var result = await base.SetEmailAsync(user, email);

        result.CheckErrors();

        if (!string.IsNullOrEmpty(oldMail) && !oldMail.Equals(email, StringComparison.OrdinalIgnoreCase))
        {
            await DistributedEventBus.PublishAsync(
                new IdentityUserEmailChangedEto
                {
                    Id = user.Id,
                    TenantId = user.TenantId,
                    Email = email,
                    OldEmail = oldMail
                });
        }

        return result;
    }

    public async override Task<IdentityResult> SetUserNameAsync(IdentityUser user, string userName)
    {
        var oldUserName = user.UserName;

        var result = await base.SetUserNameAsync(user, userName);

        result.CheckErrors();

        if (!string.IsNullOrEmpty(oldUserName) && oldUserName != userName)
        {
            await DistributedEventBus.PublishAsync(
                new IdentityUserUserNameChangedEto
                {
                    Id = user.Id,
                    TenantId = user.TenantId,
                    UserName = userName,
                    OldUserName = oldUserName
                });
        }

        return result;
    }

    public override async Task<IdentityResult> ChangePasswordAsync(IdentityUser user, string currentPassword, string newPassword)
    {
        var result = await base.ChangePasswordAsync(user, currentPassword, newPassword);

        result.CheckErrors();

        await DistributedEventBus.PublishAsync(new IdentityUserPasswordChangedEto
        {
            Id = user.Id,
            TenantId = user.TenantId,
            Email =  user.Email,
        });

        return result;
    }

    public virtual async Task UpdateRoleAsync(Guid sourceRoleId, Guid? targetRoleId)
    {
        var sourceRole = await RoleRepository.GetAsync(sourceRoleId, cancellationToken: CancellationToken);

        Logger.LogDebug($"Remove dynamic claims cache for users of role: {sourceRoleId}");
        var userIdList = await UserRepository.GetUserIdListByRoleIdAsync(sourceRoleId, cancellationToken: CancellationToken);
        await DynamicClaimCache.RemoveManyAsync(userIdList.Select(userId => AbpDynamicClaimCacheItem.CalculateCacheKey(userId, sourceRole.TenantId)), token: CancellationToken);

        var targetRole = targetRoleId.HasValue ? await RoleRepository.GetAsync(targetRoleId.Value, cancellationToken: CancellationToken) : null;
        if (targetRole != null)
        {
            Logger.LogDebug($"Remove dynamic claims cache for users of role: {targetRoleId}");
            userIdList = await UserRepository.GetUserIdListByRoleIdAsync(targetRoleId.Value, cancellationToken: CancellationToken);
            await DynamicClaimCache.RemoveManyAsync(userIdList.Select(userId => AbpDynamicClaimCacheItem.CalculateCacheKey(userId, targetRole.TenantId)), token: CancellationToken);
        }

        await UserRepository.UpdateRoleAsync(sourceRoleId, targetRoleId, CancellationToken);
    }

    public virtual async Task UpdateOrganizationAsync(Guid sourceOrganizationId, Guid? targetOrganizationId)
    {
        var sourceOrganization = await OrganizationUnitRepository.GetAsync(sourceOrganizationId, cancellationToken: CancellationToken);

        Logger.LogDebug($"Remove dynamic claims cache for users of organization: {sourceOrganizationId}");
        var userIdList = await OrganizationUnitRepository.GetMemberIdsAsync(sourceOrganizationId, includeChildren: true, cancellationToken: CancellationToken);
        await DynamicClaimCache.RemoveManyAsync(userIdList.Select(userId => AbpDynamicClaimCacheItem.CalculateCacheKey(userId, sourceOrganization.TenantId)), token: CancellationToken);

        var targetOrganization = targetOrganizationId.HasValue ? await OrganizationUnitRepository.GetAsync(targetOrganizationId.Value, cancellationToken: CancellationToken) : null;
        if (targetOrganization != null)
        {
            Logger.LogDebug($"Remove dynamic claims cache for users of organization: {targetOrganizationId}");
            userIdList = await OrganizationUnitRepository.GetMemberIdsAsync(targetOrganizationId.Value, includeChildren: true, cancellationToken: CancellationToken);
            await DynamicClaimCache.RemoveManyAsync(userIdList.Select(userId => AbpDynamicClaimCacheItem.CalculateCacheKey(userId, targetOrganization.TenantId)), token: CancellationToken);
        }

        await UserRepository.UpdateOrganizationAsync(sourceOrganizationId, targetOrganizationId, CancellationToken);
    }

    public virtual async Task<bool> ValidateUserNameAsync(string userName, Guid? userId = null)
    {
        if (string.IsNullOrWhiteSpace(userName))
        {
            return false;
        }

        if (!string.IsNullOrEmpty(Options.User.AllowedUserNameCharacters) && userName.Any(c => !Options.User.AllowedUserNameCharacters.Contains(c)))
        {
            return false;
        }

        var owner = await FindByNameAsync(userName);
        if (owner != null && owner.Id != userId)
        {
            return false;
        }

        return true;
    }

    public virtual Task<string> GetRandomUserNameAsync(int length)
    {
        var allowedUserNameCharacters = Options.User.AllowedUserNameCharacters;
        if (allowedUserNameCharacters.IsNullOrWhiteSpace())
        {
            allowedUserNameCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._@+";
        }

        var randomUserName = string.Empty;
        var random = new Random();
        while (randomUserName.Length < length)
        {
            randomUserName += allowedUserNameCharacters[random.Next(0, allowedUserNameCharacters.Length)];
        }

        return Task.FromResult(randomUserName);
    }

    public virtual async Task<string> GetUserNameFromEmailAsync(string email)
    {
        const int maxTryCount = 20;
        var tryCount = 0;

        var userName = email.Split('@')[0];

        if (await ValidateUserNameAsync(userName))
        {
            // The username is valid.
            return userName;
        }

        if (Options.User.AllowedUserNameCharacters.IsNullOrWhiteSpace())
        {
            // The AllowedUserNameCharacters is not set. So, we are generating a random username.
            tryCount = 0;
            do
            {
                var randomUserName = userName + RandomHelper.GetRandom(1000, 9999);
                if ( await ValidateUserNameAsync(randomUserName))
                {
                    return randomUserName;
                }
                tryCount++;
            } while (tryCount < maxTryCount);
        }
        else if (!userName.All(Options.User.AllowedUserNameCharacters.Contains))
        {
            // The username contains not allowed characters. So, we are generating a random username.
            do
            {
                var randomUserName = await GetRandomUserNameAsync(userName.Length);
                if ( await ValidateUserNameAsync(randomUserName))
                {
                    return randomUserName;
                }
                tryCount++;
            } while (tryCount < maxTryCount);
        }
        else if (Options.User.AllowedUserNameCharacters.Where(char.IsDigit).Distinct().Count() >= 4)
        {
            // The AllowedUserNameCharacters includes at least 4 distinct digits. So, we are picking 4 random digits from them and appending to the username.
            var allowedDigits = Options.User.AllowedUserNameCharacters.Where(char.IsDigit).Distinct().ToArray();
            tryCount = 0;
            do
            {
                var randomDigits = new char[4];
                for (var i = 0; i < randomDigits.Length; i++)
                {
                    randomDigits[i] = allowedDigits[RandomHelper.GetRandom(0, allowedDigits.Length)];
                }
                var randomUserName = userName + new string(randomDigits);
                if (await ValidateUserNameAsync(randomUserName))
                {
                    return randomUserName;
                }
                tryCount++;
            } while (tryCount < maxTryCount);
        }
        else
        {
            tryCount = 0;
            do
            {
                // The AllowedUserNameCharacters does not include numbers. So, we are generating 4 random characters and appending to the username.
                var randomUserName = userName + await GetRandomUserNameAsync(4);
                if (await ValidateUserNameAsync(randomUserName))
                {
                    return randomUserName;
                }
                tryCount++;
            } while (tryCount < maxTryCount);
        }

        Logger.LogError($"Could not get a valid user name for the given email address: {email}, allowed characters: {Options.User.AllowedUserNameCharacters}, tried {maxTryCount} times.");
        throw new AbpIdentityResultException(IdentityResult.Failed(ErrorDescriber.InvalidUserName(userName)));
    }

    public virtual async Task<IdentityUser> FindSharedUserByEmailAsync(string email)
    {
        if (MultiTenancyOptions.Value.UserSharingStrategy == TenantUserSharingStrategy.Isolated)
        {
            return await base.FindByEmailAsync(email);
        }

        using (CurrentTenant.Change(null))
        {
            using (DataFilter.Disable<IMultiTenant>())
            {
                var normalizedEmail = NormalizeEmail(email);
                var hostusers = await UserRepository.GetUsersByNormalizedEmailAsync(normalizedEmail, cancellationToken: CancellationToken);
                //host user first
                var hostUser = hostusers.FirstOrDefault(x => x.TenantId == null) ?? hostusers.FirstOrDefault(x => x.TenantId != Guid.Empty) ?? hostusers.FirstOrDefault();
                if (hostUser == null)
                {
                    return null;
                }

                using (DataFilter.Enable<IMultiTenant>())
                {
                    using (CurrentTenant.Change(hostUser.TenantId))
                    {
                        return await base.FindByEmailAsync(email);
                    }
                }
            }
        }
    }

    public virtual async Task<IdentityUser> FindSharedUserByNameAsync(string userName)
    {
        if (MultiTenancyOptions.Value.UserSharingStrategy == TenantUserSharingStrategy.Isolated)
        {
            return await base.FindByNameAsync(userName);
        }

        using (CurrentTenant.Change(null))
        {
            using (DataFilter.Disable<IMultiTenant>())
            {
                var normalizeduserName = NormalizeName(userName);
                var hostusers = await UserRepository.GetUsersByNormalizedUserNameAsync(normalizeduserName, cancellationToken: CancellationToken);
                //host user first
                var hostUser = hostusers.FirstOrDefault(x => x.TenantId == null) ?? hostusers.FirstOrDefault(x => x.TenantId != Guid.Empty) ?? hostusers.FirstOrDefault();
                if (hostUser == null)
                {
                    return null;
                }

                using (DataFilter.Enable<IMultiTenant>())
                {
                    using (CurrentTenant.Change(hostUser.TenantId))
                    {
                        return await base.FindByNameAsync(userName);
                    }
                }
            }
        }
    }

    public virtual async Task<IdentityUser> FindSharedUserByLoginAsync(string loginProvider, string providerKey)
    {
        if (MultiTenancyOptions.Value.UserSharingStrategy == TenantUserSharingStrategy.Isolated)
        {
            return await base.FindByLoginAsync(loginProvider, providerKey);
        }

        using (CurrentTenant.Change(null))
        {
            using (DataFilter.Disable<IMultiTenant>())
            {
                var hostusers = await UserRepository.GetUsersByLoginAsync(loginProvider, providerKey, cancellationToken: CancellationToken);
                //host user first
                var hostUser = hostusers.FirstOrDefault(x => x.TenantId == null) ?? hostusers.FirstOrDefault(x => x.TenantId != Guid.Empty) ?? hostusers.FirstOrDefault();
                if (hostUser == null)
                {
                    return null;
                }

                using (DataFilter.Enable<IMultiTenant>())
                {
                    using (CurrentTenant.Change(hostUser.TenantId))
                    {
                        return await base.FindByLoginAsync(loginProvider, providerKey);
                    }
                }
            }
        }
    }

    public virtual async Task<IdentityUser> FindSharedUserByPasskeyIdAsync(byte[] credentialId)
    {
        if (MultiTenancyOptions.Value.UserSharingStrategy == TenantUserSharingStrategy.Isolated)
        {
            return await base.FindByPasskeyIdAsync(credentialId);
        }

        using (CurrentTenant.Change(null))
        {
            using (DataFilter.Disable<IMultiTenant>())
            {
                var hostusers = await UserRepository.GetUsersByPasskeyIdAsync(credentialId, cancellationToken: CancellationToken);
                //host user first
                var hostUser = hostusers.FirstOrDefault(x => x.TenantId == null) ?? hostusers.FirstOrDefault(x => x.TenantId != Guid.Empty) ?? hostusers.FirstOrDefault();
                if (hostUser == null)
                {
                    return null;
                }

                using (DataFilter.Enable<IMultiTenant>())
                {
                    using (CurrentTenant.Change(hostUser.TenantId))
                    {
                        return await base.FindByPasskeyIdAsync(credentialId);
                    }
                }
            }
        }
    }

    public virtual async Task<IdentityUser> FindSharedUserByIdAsync(string userId)
    {
        if (MultiTenancyOptions.Value.UserSharingStrategy == TenantUserSharingStrategy.Isolated)
        {
            return await base.FindByIdAsync(userId);
        }

        using (CurrentTenant.Change(null))
        {
            using (DataFilter.Disable<IMultiTenant>())
            {
                var user = await base.FindByIdAsync(userId);
                if (user == null)
                {
                    return null;
                }

                using (DataFilter.Enable<IMultiTenant>())
                {
                    using (CurrentTenant.Change(user.TenantId))
                    {
                        return await base.FindByIdAsync(userId);
                    }
                }
            }
        }
    }
}
