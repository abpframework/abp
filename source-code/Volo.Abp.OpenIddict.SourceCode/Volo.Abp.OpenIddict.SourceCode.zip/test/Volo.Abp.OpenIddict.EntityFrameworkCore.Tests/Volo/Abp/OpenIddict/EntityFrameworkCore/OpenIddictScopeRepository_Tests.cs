﻿namespace Volo.Abp.OpenIddict.EntityFrameworkCore;

public class OpenIddictScopeRepository_Tests : OpenIddictScopeRepository_Tests<OpenIddictEntityFrameworkCoreTestModule>
{
    
}