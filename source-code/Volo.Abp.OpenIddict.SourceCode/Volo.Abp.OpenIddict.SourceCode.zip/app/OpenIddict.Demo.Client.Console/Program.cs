﻿using System.Net.Http.Headers;
using System.Text.Json;
using Duende.IdentityModel.Client;
using Volo.Abp.AspNetCore.Mvc.ApplicationConfigurations;

const string email = "admin@abp.io";
const string password = "1q2w3E*";
const string server = "https://localhost:44301/";
const string serverApi = "https://localhost:44301/api/abp/application-configuration";
const string api = "https://localhost:44303/api/claims";
const string clientId = "AbpApp";
const string clientSecret = "1q2w3e*";

var client = new HttpClient();

var configuration = await client.GetDiscoveryDocumentAsync(server);
if (configuration.IsError)
{
    throw new Exception(configuration.Error);
}

var passwordTokenRequest = new PasswordTokenRequest
{
    Address = configuration.TokenEndpoint,
    ClientId = clientId,
    ClientSecret = clientSecret,
    UserName = email,
    Password = password,
    Scope = "AbpAPI profile roles email phone offline_access",
};
passwordTokenRequest.Headers.Add("__tenant", "Default");
var tokenResponse = await client.RequestPasswordTokenAsync(passwordTokenRequest);

if (tokenResponse.IsError)
{
    throw new Exception(tokenResponse.Error);
}

Console.WriteLine("Access token: {0}", tokenResponse.AccessToken);
Console.WriteLine();
Console.WriteLine("Refresh token: {0}", tokenResponse.RefreshToken);
Console.WriteLine();

var refreshTokenResponse = await client.RequestRefreshTokenAsync(new RefreshTokenRequest()
{
    Address = configuration.TokenEndpoint,
    ClientId = clientId,
    ClientSecret = clientSecret,
    RefreshToken = tokenResponse.RefreshToken
});

if (refreshTokenResponse.IsError)
{
    throw new Exception(refreshTokenResponse.Error);
}

Console.WriteLine("New Access token: {0}", refreshTokenResponse.AccessToken);
Console.WriteLine();
Console.WriteLine("New Refresh token: {0}", refreshTokenResponse.RefreshToken);
Console.WriteLine();

var userinfo = await client.GetUserInfoAsync(new UserInfoRequest()
{
    Address = configuration.UserInfoEndpoint,
    Token = tokenResponse.AccessToken
});
if (userinfo.IsError)
{
    throw new Exception(userinfo.Error);
}

Console.WriteLine("UserInfo: {0}", JsonSerializer.Serialize(JsonDocument.Parse(userinfo.Raw), new JsonSerializerOptions
{
    WriteIndented = true
}));
Console.WriteLine();

var tokenExchangeResponse = await client.RequestTokenExchangeTokenAsync(new TokenExchangeTokenRequest()
{
    Address = configuration.TokenEndpoint,
    ClientId = clientId,
    ClientSecret = clientSecret,
    SubjectToken = refreshTokenResponse.AccessToken!,
    SubjectTokenType = "urn:ietf:params:oauth:token-type:access_token",
    Scope = "AbpAPI profile roles email phone offline_access",
});

if (tokenExchangeResponse.IsError)
{
    throw new Exception(tokenExchangeResponse.Error);
}

Console.WriteLine("Token Exchange token: {0}", tokenExchangeResponse.AccessToken);
Console.WriteLine();
Console.WriteLine("Token Exchange token: {0}", tokenExchangeResponse.RefreshToken);
Console.WriteLine();

userinfo = await client.GetUserInfoAsync(new UserInfoRequest()
{
    Address = configuration.UserInfoEndpoint,
    Token = tokenExchangeResponse.AccessToken
});
if (userinfo.IsError)
{
    throw new Exception(userinfo.Error);
}

Console.WriteLine("Token Exchange UserInfo: {0}", JsonSerializer.Serialize(JsonDocument.Parse(userinfo.Raw), new JsonSerializerOptions
{
    WriteIndented = true
}));
Console.WriteLine();

var introspectionResponse  = await client.IntrospectTokenAsync(new TokenIntrospectionRequest()
{
    Address = configuration.IntrospectionEndpoint,
    ClientId = clientId,
    ClientSecret = clientSecret,
    Token = tokenResponse.AccessToken,
    TokenTypeHint = "access_token"
});
if (introspectionResponse.IsError)
{
    throw new Exception(introspectionResponse.Error);
}

Console.WriteLine("Introspection : {0}", JsonSerializer.Serialize(JsonDocument.Parse(introspectionResponse.Raw), new JsonSerializerOptions
{
    WriteIndented = true
}));
Console.WriteLine();

var serverRequest = new HttpRequestMessage(HttpMethod.Get, serverApi);
serverRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", tokenResponse.AccessToken);

var serverResponse = await client.SendAsync(serverRequest);
serverResponse.EnsureSuccessStatusCode();

var dto = JsonSerializer.Deserialize<ApplicationConfigurationDto>(await serverResponse.Content.ReadAsStringAsync(), new JsonSerializerOptions()
{
    PropertyNamingPolicy = JsonNamingPolicy.CamelCase
});
Console.WriteLine("Server API response: {0}", JsonSerializer.Serialize(dto.CurrentUser, new JsonSerializerOptions
{
    WriteIndented = true
}));

Console.WriteLine();

var request = new HttpRequestMessage(HttpMethod.Get, api);
request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", tokenResponse.AccessToken);

var response = await client.SendAsync(request);
response.EnsureSuccessStatusCode();

Console.WriteLine("API response: {0}", JsonSerializer.Serialize(JsonDocument.Parse(await response.Content.ReadAsStringAsync()), new JsonSerializerOptions
{
    WriteIndented = true
}));

Console.WriteLine();

client = new HttpClient();

tokenResponse = await client.RequestClientCredentialsTokenAsync(new ClientCredentialsTokenRequest
{
    Address = configuration.TokenEndpoint,

    ClientId = clientId,
    ClientSecret = clientSecret,

    Scope = "AbpAPI offline_access",
});

if (tokenResponse.IsError)
{
    Console.WriteLine(tokenResponse.Error);
    return;
}

Console.WriteLine("Access token: {0}", tokenResponse.AccessToken);
Console.WriteLine();
Console.WriteLine("Refresh token: {0}", tokenResponse.RefreshToken);
Console.WriteLine();

serverRequest = new HttpRequestMessage(HttpMethod.Get, api);
serverRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", tokenResponse.AccessToken);

serverResponse = await client.SendAsync(serverRequest);
serverResponse.EnsureSuccessStatusCode();

Console.WriteLine("ClientCredentials API response: {0}", JsonSerializer.Serialize(JsonDocument.Parse(await serverResponse.Content.ReadAsStringAsync()), new JsonSerializerOptions
{
    WriteIndented = true
}));

Console.WriteLine();
