// This file is part of DocumentsAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Docs.Admin.ClientProxies;

public partial class DocumentsAdminClientProxy
{
}
