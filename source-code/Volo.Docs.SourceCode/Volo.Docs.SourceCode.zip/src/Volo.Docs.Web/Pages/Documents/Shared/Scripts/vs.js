(function ($) {
    $(function () {

        var scrollTopBtn = $('.scroll-top-btn');
        var enoughHeight = $('.docs-sidebar-wrapper > .docs-top').height();
        var enoughHeightPlus = 500;

        $(window).scroll(function () {
            var topPos = $(window).scrollTop();
            if (topPos > enoughHeight) {
                $(scrollTopBtn).addClass('showup');
                $('body').addClass('scrolled');
            } else {
                $(scrollTopBtn).removeClass('showup');
                $('body').removeClass('scrolled');
            }
            if (topPos > enoughHeightPlus) {
                $('body').addClass('scrolledMore');
            } else {
                $('body').removeClass('scrolledMore');
            }
        });

        $(scrollTopBtn).click(function () {
            $('html, body').animate(
                {
                    scrollTop: 0,
                },
                500
            );
            return false;
        });

        var scrollToHashLink = function () {
            var hash = window.location.hash;

            if (!hash || hash === '#' || hash === '#gsc.tab=0') {
                return;
            }

            hash = hash.split('&')[0];

            var $targetElement = $(decodeURIComponent(hash));

            $targetElement = $targetElement.length
                ? $targetElement
                : $('[name=' + hash.slice(1) + ']');

            if (!$targetElement.length) {
                return;
            }

            $('html,body').stop().animate(
                {
                    scrollTop: $targetElement.offset().top,
                },
                200
            );

            return;
        };

        $(document).ready(function () {
            var $myNav = $('#docs-sticky-index');

            if ($myNav.length === 0) {
                return;
            }

            $('body').scrollspy({
                target: $myNav,
                offset:100
            });

            $('#docs-sticky-index a').on('click', function (event) {
                if (this.hash !== '') {
                    event.preventDefault();
                    var hash = this.hash;
                    $('html, body').animate(
                        {
                            scrollTop: $(decodeURIComponent(hash)).offset().top,
                        },
                        500,
                        function () {
                            window.location.hash = hash;
                        }
                    );
                }
            });

            $("body").on('activate.bs.scrollspy', function (e) {
                var $activeLink = $('.nav-link.active', $('#docs-sticky-index'));

                var $activeLi = $activeLink.parent('li.nav-item');

                $myNav.find('li.toc-item-has-children.open').each(function () {
                    if ($(this).has($activeLi).length === 0) {
                        $(this).removeClass('open');
                    }
                });

                var $parentToOpen = $activeLi.closest('li.toc-item-has-children');
                if ($parentToOpen.length > 0) {
                    $parentToOpen.addClass('open');
                }
            });

            $('.btn-toggle').on('click', function () {
                $('.toggle-row').slideToggle(400);
                $(this).toggleClass('less');
            });

            $('.close-mmenu').on('click', function () {
                $('.navbar-collapse').removeClass('show');
            });

            $('.open-dmenu').on('click', function () {
                $('.docs-tree-list').slideToggle();
            });

            initMenuToggle();
            scrollToHashLink();
        });
    });

     function initMenuToggle() {
        $('li:not(.last-link) a.tree-toggle').off('click');
        $('li:not(.last-link) span.plus-icon i.fa-chevron-right').off('click');
        
        $('li:not(.last-link) a.tree-toggle').click(function () {
            $(this).parent().children('ul.tree').toggle(100);
            $(this).closest('li').toggleClass('selected-tree');
        });

        $('li:not(.last-link) span.plus-icon i.fa-chevron-right').click(
            function () {
                var $element = $(this).parent();
                var $filter = $('.docs-version #filter');

                if ($filter && $filter.val() != ''){
                    return;
                }

                $element.parent().children('ul.tree').toggle(100);
                $element.closest('li').toggleClass('selected-tree');
            }
        );
    }

    function docsCriteria() {
        var docsContentWidth = $('.docs-content').width() - 74;
        $('.alert-criteria').width(docsContentWidth);
    }

    // Toggle the collapsed document-options popover by click/tap (works on touch, unlike a hover-only reveal).
    function docsOptionsToggle() {
        var $criteria = $('.alert-criteria');
        var $btn = $criteria.find('.options-header .toggle-btn');
        if (!$criteria.length || !$btn.length) {
            return;
        }
        function setOpen(isOpen) {
            $criteria.toggleClass('is-open', isOpen);
            $btn.attr('aria-expanded', isOpen ? 'true' : 'false');
        }
        // clear any previous bindings so a second init (e.g. partial reload) does not stack handlers
        $btn.off('.docsOptions');
        $criteria.off('.docsOptions');
        $(document).off('.docsOptions');
        $(window).off('.docsOptions');
        $btn.on('click.docsOptions', function (e) {
            e.preventDefault();
            e.stopPropagation();
            setOpen(!$criteria.hasClass('is-open'));
        });
        $criteria.on('click.docsOptions', function (e) {
            e.stopPropagation();
        });
        $(document).on('click.docsOptions', function () {
            setOpen(false);
        });
        $(document).on('keydown.docsOptions', function (e) {
            if (e.key === 'Escape' && $criteria.hasClass('is-open')) {
                setOpen(false);
                // keyboard close: return focus to the button (focus ring is appropriate here)
                $btn.trigger('focus');
            }
        });
        $(window).on('scroll.docsOptions', function () {
            if (!$('body').hasClass('scrolledMore')) {
                setOpen(false);
            }
        });
    }

    $(document).ready(function () {
        docsCriteria();
        docsOptionsToggle();
    });
    $(window).resize(function () {
        docsCriteria();
    });
})(jQuery);
