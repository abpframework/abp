﻿using System;

namespace Volo.Docs.Admin.Projects
{
    public class ReindexInput
    {
        public Guid ProjectId { get; set; }
    }
}
