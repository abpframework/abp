// This file is part of MembersClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Blogging.ClientProxies;

public partial class MembersClientProxy
{
}
