// This file is part of PostsClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Blogging.ClientProxies;

public partial class PostsClientProxy
{
}
