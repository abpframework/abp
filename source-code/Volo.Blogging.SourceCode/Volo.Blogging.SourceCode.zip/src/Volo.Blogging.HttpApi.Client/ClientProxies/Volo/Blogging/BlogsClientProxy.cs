// This file is part of BlogsClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Blogging;

public partial class BlogsClientProxy
{
}
