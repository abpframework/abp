﻿namespace Volo.Blogging.SocialMedia
{
    public class BloggingTwitterOptions
    {
        public string Site { get; set; }
    }
}
