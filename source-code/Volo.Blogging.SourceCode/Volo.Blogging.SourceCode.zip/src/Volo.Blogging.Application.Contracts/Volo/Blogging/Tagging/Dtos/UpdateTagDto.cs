﻿namespace Volo.Blogging.Tagging.Dtos
{
    public class UpdateTagDto
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}