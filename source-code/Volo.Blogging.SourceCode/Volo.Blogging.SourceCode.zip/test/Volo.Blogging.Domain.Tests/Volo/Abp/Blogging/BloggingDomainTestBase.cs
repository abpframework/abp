﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volo.Blogging
{
    public abstract class BloggingDomainTestBase : BloggingTestBase<BloggingTestBaseModule>
    {

    }
}
