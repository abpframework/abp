﻿using Volo.Abp.Localization;

namespace Volo.Abp.Identity.Localization
{
    [LocalizationResourceName("AbpIdentity")]
    public class IdentityResource
    {
        
    }
}
