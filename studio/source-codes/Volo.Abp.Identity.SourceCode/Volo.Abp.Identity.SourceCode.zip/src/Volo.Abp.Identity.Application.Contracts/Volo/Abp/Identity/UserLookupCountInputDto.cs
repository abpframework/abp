﻿namespace Volo.Abp.Identity
{
    public class UserLookupCountInputDto
    {
        public string Filter { get; set; }
    }
}