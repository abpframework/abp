// This file is part of DocsDocumentClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Docs.Documents.ClientProxies
{
    public partial class DocsDocumentClientProxy
    {
    }
}
