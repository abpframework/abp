﻿using AutoMapper;

namespace Volo.CmsKit
{
    public class CmsKitWebAutoMapperProfile : Profile
    {
        public CmsKitWebAutoMapperProfile()
        {
            //Define your AutoMapper configuration here for the Web project.
        }
    }
}
