// This file is part of BlogAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Admin.Blogs.ClientProxies
{
    public partial class BlogAdminClientProxy
    {
    }
}
