// This file is part of PageAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Admin.Pages.ClientProxies
{
    public partial class PageAdminClientProxy
    {
    }
}
