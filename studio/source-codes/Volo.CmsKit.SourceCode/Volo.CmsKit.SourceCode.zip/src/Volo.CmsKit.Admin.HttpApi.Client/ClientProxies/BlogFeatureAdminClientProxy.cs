// This file is part of BlogFeatureAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Admin.Blogs.ClientProxies
{
    public partial class BlogFeatureAdminClientProxy
    {
    }
}
