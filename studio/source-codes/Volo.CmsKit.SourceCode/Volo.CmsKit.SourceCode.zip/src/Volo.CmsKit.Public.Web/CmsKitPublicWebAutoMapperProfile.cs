﻿using AutoMapper;

namespace Volo.CmsKit.Public.Web
{
    public class CmsKitPublicWebAutoMapperProfile : Profile
    {
        public CmsKitPublicWebAutoMapperProfile()
        {

        }
    }
}
