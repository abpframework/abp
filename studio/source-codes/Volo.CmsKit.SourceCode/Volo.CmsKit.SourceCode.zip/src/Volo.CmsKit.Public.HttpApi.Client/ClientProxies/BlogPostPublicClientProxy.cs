// This file is part of BlogPostPublicClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Public.Blogs.ClientProxies
{
    public partial class BlogPostPublicClientProxy
    {
    }
}
