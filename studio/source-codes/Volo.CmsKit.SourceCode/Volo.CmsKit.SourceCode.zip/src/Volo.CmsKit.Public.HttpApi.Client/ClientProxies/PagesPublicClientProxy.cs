// This file is part of PagesPublicClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Public.Pages.ClientProxies
{
    public partial class PagesPublicClientProxy
    {
    }
}
