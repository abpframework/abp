// This file is part of MenuItemPublicClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Public.Menus.ClientProxies
{
    public partial class MenuItemPublicClientProxy
    {
    }
}
