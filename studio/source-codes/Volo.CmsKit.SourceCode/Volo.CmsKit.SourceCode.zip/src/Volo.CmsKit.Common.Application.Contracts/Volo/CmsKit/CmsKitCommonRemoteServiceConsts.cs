﻿namespace Volo.CmsKit
{
    public class CmsKitCommonRemoteServiceConsts
    {
        public const string RemoteServiceName = "CmsKitCommon";
    }
}