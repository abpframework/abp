﻿using Volo.CmsKit.Tags;

namespace Volo.CmsKit.EntityFrameworkCore.Tags
{
    public class TagRepository_Test : TagRepository_Test<CmsKitEntityFrameworkCoreTestModule>
    {
        
    }
}