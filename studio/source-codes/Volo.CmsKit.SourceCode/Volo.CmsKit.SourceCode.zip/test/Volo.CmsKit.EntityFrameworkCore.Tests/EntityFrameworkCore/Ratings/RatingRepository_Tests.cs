﻿using Volo.CmsKit.Ratings;

namespace Volo.CmsKit.EntityFrameworkCore.Ratings
{
    public class RatingRepository_Tests : RatingRepository_Tests<CmsKitEntityFrameworkCoreTestModule>
    {
        
    }
}