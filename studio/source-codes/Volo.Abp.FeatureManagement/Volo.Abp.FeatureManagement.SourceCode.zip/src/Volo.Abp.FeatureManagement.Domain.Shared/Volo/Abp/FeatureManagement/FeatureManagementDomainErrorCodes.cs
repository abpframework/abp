﻿using System;

namespace Volo.Abp.FeatureManagement
{
    public static class FeatureManagementDomainErrorCodes
    {
        public const string FeatureValueInvalid = "Volo.Abp.FeatureManagement:InvalidFeatureValue";
    }
}
