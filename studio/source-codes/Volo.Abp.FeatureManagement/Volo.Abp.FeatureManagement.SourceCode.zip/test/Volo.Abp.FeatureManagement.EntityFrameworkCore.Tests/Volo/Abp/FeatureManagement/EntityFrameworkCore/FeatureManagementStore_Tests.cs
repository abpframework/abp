﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volo.Abp.FeatureManagement.EntityFrameworkCore
{
    public class FeatureManagementStore_Tests : FeatureManagementStore_Tests<AbpFeatureManagementEntityFrameworkCoreTestModule>
    {

    }
}
