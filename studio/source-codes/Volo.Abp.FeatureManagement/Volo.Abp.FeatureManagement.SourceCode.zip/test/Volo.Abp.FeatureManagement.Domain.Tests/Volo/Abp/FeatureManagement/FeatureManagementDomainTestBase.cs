﻿namespace Volo.Abp.FeatureManagement
{
    public abstract class FeatureManagementDomainTestBase : FeatureManagementTestBase<AbpFeatureManagementDomainTestModule>
    {

    }
}