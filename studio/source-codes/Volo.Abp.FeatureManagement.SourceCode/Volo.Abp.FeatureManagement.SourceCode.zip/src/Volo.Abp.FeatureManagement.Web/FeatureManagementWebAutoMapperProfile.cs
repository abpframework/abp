﻿using AutoMapper;

namespace Volo.Abp.FeatureManagement;

public class FeatureManagementWebAutoMapperProfile : Profile
{
    public FeatureManagementWebAutoMapperProfile()
    {
        //Create mappings.
    }
}
