// This file is part of MenuItemAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Admin.Menus.ClientProxies
{
    public partial class MenuItemAdminClientProxy
    {
    }
}
