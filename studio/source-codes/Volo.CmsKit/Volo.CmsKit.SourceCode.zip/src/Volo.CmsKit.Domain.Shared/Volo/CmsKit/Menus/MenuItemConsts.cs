﻿namespace Volo.CmsKit.Menus
{
    public static class MenuItemConsts
    {
        public const int MaxDisplayNameLength = 64;
        public const int MaxUrlLength = 1024;
    }
}
