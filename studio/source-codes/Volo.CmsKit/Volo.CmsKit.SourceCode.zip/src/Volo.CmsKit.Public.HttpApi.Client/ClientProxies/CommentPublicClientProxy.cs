// This file is part of CommentPublicClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Public.Comments.ClientProxies
{
    public partial class CommentPublicClientProxy
    {
    }
}
