// This file is part of RatingPublicClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.CmsKit.Public.Ratings.ClientProxies
{
    public partial class RatingPublicClientProxy
    {
    }
}
