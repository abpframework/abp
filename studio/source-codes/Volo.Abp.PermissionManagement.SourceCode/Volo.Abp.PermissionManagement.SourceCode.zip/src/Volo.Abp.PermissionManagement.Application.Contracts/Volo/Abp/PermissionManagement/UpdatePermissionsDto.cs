﻿namespace Volo.Abp.PermissionManagement
{
    public class UpdatePermissionsDto
    {
        public UpdatePermissionDto[] Permissions { get; set; }
    }
}