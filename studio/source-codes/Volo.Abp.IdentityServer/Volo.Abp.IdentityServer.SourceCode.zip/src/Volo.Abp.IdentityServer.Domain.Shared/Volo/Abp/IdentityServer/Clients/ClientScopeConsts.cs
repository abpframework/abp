﻿namespace Volo.Abp.IdentityServer.Clients
{
    public class ClientScopeConsts
    {
        /// <summary>
        /// Default value: 200
        /// </summary>
        public static int ScopeMaxLength { get; set; } = 200;
    }
}