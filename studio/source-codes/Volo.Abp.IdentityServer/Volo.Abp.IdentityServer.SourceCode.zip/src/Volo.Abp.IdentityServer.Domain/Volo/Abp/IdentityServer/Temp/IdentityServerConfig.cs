﻿namespace Volo.Abp.IdentityServer.Temp
{
    //TODO: Remove!
    //internal static class IdentityServerConfig
    //{
    //    public static IEnumerable<ApiResource> GetApiResources()
    //    {
    //        return new List<ApiResource>
    //        {
    //            new ApiResource("api1", "My API")
    //        };
    //    }

    //    public static IEnumerable<IdentityServer4.Models.Client> GetClients()
    //    {
    //        return new List<Client>
    //        {
    //            new Client
    //            {
    //                ClientId = "client",

    //                // no interactive user, use the clientid/secret for authentication
    //                AllowedGrantTypes = GrantTypes.ClientCredentials,

    //                // secret for authentication
    //                ClientSecrets =
    //                {
    //                    new IdentityServer4.Models.Secret("secret".Sha256())
    //                },

    //                // scopes that client has access to
    //                AllowedScopes = { "api1" }
    //            }
    //        };
    //    }
    //}
}