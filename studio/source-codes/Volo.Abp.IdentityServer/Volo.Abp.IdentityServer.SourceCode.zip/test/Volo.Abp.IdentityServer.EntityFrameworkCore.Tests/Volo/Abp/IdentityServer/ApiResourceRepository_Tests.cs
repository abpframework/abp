﻿
namespace Volo.Abp.IdentityServer
{
    public class ApiResourceRepository_Tests //: ApiResourceRepository_Tests<AbpIdentityServerTestEntityFrameworkCoreModule>
    {
    }
}
