using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Volo.Abp.AspNetCore.Mvc.UI.Theme.Basic.Demo.Pages.Components.ButtonGroups
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}