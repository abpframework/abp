﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Volo.Abp.IdentityServer
{
    public class PersistentGrantRepository_Tests : PersistentGrantRepository_Tests<AbpIdentityServerTestEntityFrameworkCoreModule>
    {

    }
}
