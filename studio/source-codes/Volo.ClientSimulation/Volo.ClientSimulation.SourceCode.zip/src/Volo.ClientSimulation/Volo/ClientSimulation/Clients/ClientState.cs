﻿namespace Volo.ClientSimulation.Clients
{
    public enum ClientState
    {
        Stopped,
        Running,
        Stopping
    }
}