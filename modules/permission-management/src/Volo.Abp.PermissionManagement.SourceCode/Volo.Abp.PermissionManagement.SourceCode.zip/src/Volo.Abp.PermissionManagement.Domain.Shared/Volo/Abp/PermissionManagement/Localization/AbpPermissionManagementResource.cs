﻿using Volo.Abp.Localization;

namespace Volo.Abp.PermissionManagement.Localization
{
    [LocalizationResourceName("AbpPermissionManagement")]
    public class AbpPermissionManagementResource
    {
        
    }
}
