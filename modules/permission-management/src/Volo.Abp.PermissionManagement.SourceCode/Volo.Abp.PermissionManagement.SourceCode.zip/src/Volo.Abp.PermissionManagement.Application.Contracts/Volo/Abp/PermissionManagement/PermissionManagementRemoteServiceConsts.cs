﻿namespace Volo.Abp.PermissionManagement
{
    public class PermissionManagementRemoteServiceConsts
    {
        public const string RemoteServiceName = "AbpPermissionManagement";
    }
}