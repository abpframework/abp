﻿using Volo.Blogging.EntityFrameworkCore;
using Volo.Blogging.Posts;

namespace Volo.Blogging
{
    public class PostRepository_Tests : PostRepository_Tests<BloggingEntityFrameworkCoreTestModule>
    {
    }
}