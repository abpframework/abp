﻿namespace Volo.Docs.GitHub.Documents.Version
{
    public class GithubVersion
    {
        public string Name { get; set; }
    }
}