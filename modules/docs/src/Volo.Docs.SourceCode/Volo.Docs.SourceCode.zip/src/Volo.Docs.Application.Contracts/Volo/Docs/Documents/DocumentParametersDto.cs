﻿using System.Collections.Generic;

namespace Volo.Docs.Documents
{
    public class DocumentParametersDto
    {
        public List<DocumentParameterDto> Parameters {get;set;}
    }
}