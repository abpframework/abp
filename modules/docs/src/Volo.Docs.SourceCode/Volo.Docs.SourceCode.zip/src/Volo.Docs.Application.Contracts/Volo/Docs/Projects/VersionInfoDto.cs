﻿namespace Volo.Docs.Projects
{
    public class VersionInfoDto
    {
        public string DisplayName { get; set; }

        public string Name { get; set; }
    }
}
