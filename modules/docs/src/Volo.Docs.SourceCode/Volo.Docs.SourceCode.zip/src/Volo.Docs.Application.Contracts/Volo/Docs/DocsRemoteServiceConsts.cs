﻿namespace Volo.Docs
{
    public static class DocsRemoteServiceConsts
    {
        public const string RemoteServiceName = "AbpDocs";
    }
}
