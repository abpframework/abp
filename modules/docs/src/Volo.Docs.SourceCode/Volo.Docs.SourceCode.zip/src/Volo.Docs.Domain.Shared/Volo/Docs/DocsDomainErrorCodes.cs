﻿namespace Volo.Docs
{
    public static class DocsDomainErrorCodes
    {
        public const string ElasticSearchNotEnabled = "Volo.Docs.Domain:010001";
    }
}