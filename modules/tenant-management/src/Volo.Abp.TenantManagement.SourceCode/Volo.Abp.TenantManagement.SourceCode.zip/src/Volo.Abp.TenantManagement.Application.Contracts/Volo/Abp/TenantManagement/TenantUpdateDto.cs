﻿namespace Volo.Abp.TenantManagement
{
    public class TenantUpdateDto : TenantCreateOrUpdateDtoBase
    {

    }
}