export const enum eTenantManagementRouteNames {
  TenantManagement = 'AbpTenantManagement::Menu:TenantManagement',
  Tenants = 'AbpTenantManagement::Tenants',
}
