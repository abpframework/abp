﻿using Volo.Abp.Identity.EntityFrameworkCore;

namespace Volo.Abp.Identity.MongoDB
{
    public class IdentityClaimTypeRepository_Tests : IdentityClaimTypeRepository_Tests<AbpIdentityEntityFrameworkCoreTestModule>
    {

    }
}
