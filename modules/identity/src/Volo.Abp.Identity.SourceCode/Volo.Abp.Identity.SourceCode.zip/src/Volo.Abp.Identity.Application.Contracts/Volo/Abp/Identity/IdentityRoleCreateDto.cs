﻿namespace Volo.Abp.Identity
{
    public class IdentityRoleCreateDto : IdentityRoleCreateOrUpdateDtoBase
    {

    }
}