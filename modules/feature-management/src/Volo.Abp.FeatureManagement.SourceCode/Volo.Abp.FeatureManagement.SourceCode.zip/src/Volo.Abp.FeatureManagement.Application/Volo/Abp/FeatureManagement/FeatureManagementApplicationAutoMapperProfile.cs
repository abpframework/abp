﻿using AutoMapper;

namespace Volo.Abp.FeatureManagement
{
    public class FeatureManagementApplicationAutoMapperProfile : Profile
    {
        public FeatureManagementApplicationAutoMapperProfile()
        {
            
        }
    }
}