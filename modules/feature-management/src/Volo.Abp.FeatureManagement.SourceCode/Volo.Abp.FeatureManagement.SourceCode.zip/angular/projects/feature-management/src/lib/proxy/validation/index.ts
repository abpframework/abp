export * as StringValues from './string-values';
