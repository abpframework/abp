export const enum eFeatureManagementComponents {
  FeatureManagement = 'FeatureManagement.FeatureManagementComponent',
}
