﻿using Volo.Abp.AspNetCore.Mvc.Authentication;

namespace Volo.CmsKit.Controllers
{
    public class AccountController : ChallengeAccountController
    {

    }
}
