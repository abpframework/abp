﻿namespace Volo.CmsKit.Blogs
{
    public static class BlogFeatureConsts
    {
        public const int MaxFeatureNameLenth = 64;
    }
}
