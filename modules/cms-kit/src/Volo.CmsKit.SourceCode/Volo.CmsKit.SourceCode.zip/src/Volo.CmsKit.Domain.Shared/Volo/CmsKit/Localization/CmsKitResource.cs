﻿using Volo.Abp.Localization;

namespace Volo.CmsKit.Localization
{
    [LocalizationResourceName("CmsKit")]
    public class CmsKitResource
    {
        
    }
}
