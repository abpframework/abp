﻿namespace Volo.CmsKit.Admin.Web.Pages.CmsKit.Blogs
{
    public class IndexModel : CmsKitAdminPageModel
    {
        
    }
}
