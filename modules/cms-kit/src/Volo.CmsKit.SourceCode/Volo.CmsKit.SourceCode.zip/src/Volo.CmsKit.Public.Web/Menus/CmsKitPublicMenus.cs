﻿namespace Volo.CmsKit.Public.Web.Menus
{
    public class CmsKitPublicMenus
    {
        private const string Prefix = "CmsKit.Public";

        //Add your menu items here...
        //public const string Home = Prefix + ".MyNewMenuItem";
    }

    public class CmsKitMenus
    {
        public const string Public = "CmsKit.Public";
    }
}
