﻿namespace Volo.CmsKit.Reactions
{
    public class ReactionSummaryQueryResultItem
    {
        public string ReactionName { get; set; }

        public int Count { get; set; }
    }
}
