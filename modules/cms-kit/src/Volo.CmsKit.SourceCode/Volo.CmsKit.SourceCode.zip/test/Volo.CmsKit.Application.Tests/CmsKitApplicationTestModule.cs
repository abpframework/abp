﻿using Volo.Abp.Modularity;

namespace Volo.CmsKit
{
    [DependsOn(
        typeof(CmsKitApplicationModule),
        typeof(CmsKitDomainTestModule)
        )]
    public class CmsKitApplicationTestModule : AbpModule
    {

    }
}
