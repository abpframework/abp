﻿namespace Volo.Abp.IdentityServer.Clients
{
    public class ClientPostLogoutRedirectUriConsts
    {
        /// <summary>
        /// Default value: 200
        /// </summary>
        public static int PostLogoutRedirectUriMaxLength { get; set; } = 2000;
        public static int PostLogoutRedirectUriMaxLengthValue { get; set; } = 2000;
    }
}