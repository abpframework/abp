namespace Volo.Abp.IdentityServer
{
    public class IdentityServerSecurityLogIdentityConsts
    {
        public static string IdentityServer { get; set; } = "IdentityServer";
    }
}
