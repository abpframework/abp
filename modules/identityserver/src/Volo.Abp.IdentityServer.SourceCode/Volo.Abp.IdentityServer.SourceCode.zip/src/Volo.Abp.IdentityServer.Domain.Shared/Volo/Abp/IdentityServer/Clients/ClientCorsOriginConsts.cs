﻿namespace Volo.Abp.IdentityServer.Clients
{
    public class ClientCorsOriginConsts
    {
        public static int OriginMaxLength { get; set; } =  150;
    }
}
