import { ABP } from '@abp/ng.core';

export namespace SettingManagement {
  export interface State {
    selectedTab?: ABP.Tab;
  }
}
