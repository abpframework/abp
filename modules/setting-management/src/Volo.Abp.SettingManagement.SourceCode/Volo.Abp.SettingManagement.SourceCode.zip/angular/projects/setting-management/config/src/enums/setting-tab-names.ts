export const enum eSettingManamagementSettingTabNames {
  EmailSettingGroup = 'AbpSettingManagement::Menu:Emailing',
}
