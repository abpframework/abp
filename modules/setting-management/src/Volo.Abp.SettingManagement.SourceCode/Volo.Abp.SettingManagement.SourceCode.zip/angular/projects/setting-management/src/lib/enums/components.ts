export const enum eSettingManagementComponents {
  SettingManagement = 'SettingManagement.SettingManagementComponent',
}
