﻿namespace Volo.Abp.SettingManagement
{
    public class SettingManagementRemoteServiceConsts
    {
        public const string RemoteServiceName = "SettingManagement";
    }
}
