﻿namespace Volo.Abp.AspNetCore.Components.Server.BasicTheme.Bundling
{
    public class BlazorBasicThemeBundles
    {
        public static class Styles
        {
            public static string Global = "Blazor.BasicTheme.Global";
        }

        public static class Scripts
        {
            public static string Global = "Blazor.BasicTheme.Global";
        }
    }
}