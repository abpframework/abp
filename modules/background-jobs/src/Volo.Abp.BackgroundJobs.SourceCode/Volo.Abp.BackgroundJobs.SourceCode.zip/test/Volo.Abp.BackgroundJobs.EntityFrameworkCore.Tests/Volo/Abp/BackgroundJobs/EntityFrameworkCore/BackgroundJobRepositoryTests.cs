﻿namespace Volo.Abp.BackgroundJobs.EntityFrameworkCore
{
    public class BackgroundJobRepositoryTests : BackgroundJobRepository_Tests<AbpBackgroundJobsEntityFrameworkCoreTestModule>
    {

    }
}
