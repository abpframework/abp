﻿namespace Volo.Abp.BackgroundJobs
{
    public abstract class BackgroundJobsDomainTestBase : BackgroundJobsTestBase<AbpBackgroundJobsDomainTestModule>
    {

    }
}