module.exports = {
  entryPoints: {
    '.': {},
    './config': {}
  },
};
