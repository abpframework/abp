import { TemplateRef } from '@angular/core';

export namespace Account {
  //tslint:disable
  export interface TenantBoxComponentInputs {}
  export interface TenantBoxComponentOutputs {}
  export interface PersonalSettingsComponentInputs {}
  export interface PersonalSettingsComponentOutputs {}
  export interface ChangePasswordComponentInputs {}
  export interface ChangePasswordComponentOutputs {}
  // tslint:enable
}
