export interface AccountConfigOptions {
  redirectUrl?: string;
}
