﻿namespace Volo.Abp.AuditLogging.EntityFrameworkCore
{
    public class AuditStore_Basic_Tests : AuditStore_Basic_Tests<AbpAuditLoggingEntityFrameworkCoreTestModule>
    {

    }
}
